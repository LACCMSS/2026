#!/bin/bash

rm -r ENERGY.out H.save/ H.xml pw.H.scf.out stdoutput.err  stdoutput.out
