#!/bin/bash
#SBATCH --job-name=1-H
#SBATCH --output stdoutput.out
#SBATCH --error  stdoutput.err
#SBATCH -p production
#SBATCH --time=01:00:00
#SBATCH -n 4
#SBATCH -N 1

##--- MODULES ---##
module load anaconda3
module load compilers/intel/2019.04
module load QE/6.4.1


rm ENERGY.out

ii=0
echo "H Energy" ; mpirun -np 4 pw.x < pw.H.scf.in > pw.H.scf.out

ENERGY=$(grep ! pw.H.scf.out | awk '{ print  $5 }')

echo $ii $ENERGY > ENERGY.out

cp ./ENERGY.out ../4-plotter/data/H_Energy       # move output data to plotter

echo 'Done.'
