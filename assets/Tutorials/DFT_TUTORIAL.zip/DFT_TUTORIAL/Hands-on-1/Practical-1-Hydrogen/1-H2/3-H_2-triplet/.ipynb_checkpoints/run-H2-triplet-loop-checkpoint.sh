#!/bin/bash
#SBATCH --job-name=3-H_2-triplet
#SBATCH --output stdoutput.out
#SBATCH --error  stdoutput.err
#SBATCH -p production
#SBATCH --time=01:00:00
#SBATCH -n 8
#SBATCH -N 1

##--- MODULES ---##
module load anaconda3
module load compilers/intel/2019.04
module load QE/6.4.1


rm -r ./output_files
mkdir ./output_files
rm ENERGY.out

# 0.3 0.35 0.4 0.45 0.5 0.55

for r in    0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2 2.1 2.2 2.3 2.4 2.5 2.6 2.7 2.8 2.9 3 3.5 4  ; do # lengths in \AA

rrel=$(echo "scale=6;1.88973*($r/2)/18.8973" | bc) # converts lengths to borh and projects to relative corrdinates. Box lattice vector is 18.8973 Bohr (10 \AA) ;  1 \AA = 1.88973 Bohr

H1_x=$(echo "scale=6;0.5+$rrel" | bc) # SHIFT H1 TO RIGHT
H2_x=$(echo "scale=6;0.5-$rrel" | bc) # SHIFT H2 TO LEFT

sed 's/CHANGEH1/'"${H1_x}"'/g' ./pw.H2_triplet.scf.in.temp | sed 's/CHANGEH2/'"${H2_x}"'/g'  > pw.H2_triplet.scf.in

echo "dist=$r" ; mpirun -np 8 $PWSCFPATH/pw.x < pw.H2_triplet.scf.in > ./output_files/pw.H2_triplet.scf.${r}.out


ENERGY=$(grep ! ./output_files/pw.H2_triplet.scf.${r}.out | awk '{ print  $5 }')
echo $r $ENERGY >> ENERGY.out

done
cat ENERGY.out
 
cp ./ENERGY.out ../4-plotter/data/H2_triplet_Energy      # move output data to plotter folder

echo 'Done.'
