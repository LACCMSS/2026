#!/bin/bash
#SBATCH --job-name=0.1-Fe-BCC-LDA
#SBATCH --output stdoutput.out
#SBATCH --error  stdoutput.err
#SBATCH -p production
#SBATCH --time=01:00:00
#SBATCH --exclude=cmt-1,cmt-2
#SBATCH -n 8
#SBATCH -N 1

##--- MODULES ---##
module load anaconda3
module load compilers/intel/2019.04
module load QE/6.4.1

# Note: The lattice parameter is 3.571 A (6.748212 Bohr) for FCC iron and 2.866 A (5.4159551 Bohr) for BCC iron.


rm -r ./output_files
mkdir ./output_files
rm ENERGY.out


for ec in    20 30 40 50 60 70 80 90 100 110 120 130 140 150 160 170 ; do # ecut [Ry]


sed 's/CHANGEECUT/'"${ec}"'/g' ./pw.Fe-BCC-LDA.scf.in.temp  > pw.Fe-BCC-LDA.scf.in

echo "dist=$ec" ; mpirun -np 4 pw.x < pw.Fe-BCC-LDA.scf.in > ./output_files/pw.Fe-BCC-LDA.scf.${ec}.out


ENERGY=$(grep ! ./output_files/pw.Fe-BCC-LDA.scf.${ec}.out | awk '{ print  $5 }')
echo $ec $ENERGY >> ENERGY.out

done
cat ENERGY.out
 
echo 'Done.'
