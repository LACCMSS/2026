#!/bin/bash
#SBATCH --clusters=amarel                       # Select which system(s) to use
#SBATCH --partition=cgpu                   # Partition (job queue)
#SBATCH --nodes=1                   # Partition (job queue)
#SBATCH --requeue                            # Return job to the queue if preempted
#SBATCH --job-name=AgI                     # Assign an short name to your job
#SBATCH --gres=gpu:2                 # Request number of GPUs
#SBATCH --mem=160G                              # Real memory (RAM) required per node
#SBATCH --time=3-00:00:00                         # Total run time limit (DD-HH:MM:SS)
#SBATCH --output=slurm.%N.%j.o                  # STDOUT file for SLURM output
#SBATCH --error=slurm.%N.%j.err                 # STDERR file for Errors

## Environment settings needed for this job
module purge
module load git
source /projects/f_rcr78_1/AT/MySoftwares/pythonenv/bin/activate

nequip-train AgI.yaml
