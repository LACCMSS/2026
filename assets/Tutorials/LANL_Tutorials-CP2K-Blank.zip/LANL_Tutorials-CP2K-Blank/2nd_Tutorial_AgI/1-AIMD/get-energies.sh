grep "time" AgI-MD-pos-1.xyz | awk '{print $9}' > AgI-MD-ener.dat
