#!/bin/bash
#SBATCH --clusters=amarel            # Select which system(s) to use
#SBATCH --partition=cmain        # Partition (job queue)
#SBATCH --no-requeue                 # Return job to the queue if preempted
#SBATCH --job-name=AgI222        # Assign an short name to your job
#SBATCH --nodes=1                    # Number of nodes you require
#SBATCH --ntasks=40                   # Total # of tasks across all nodes
#SBATCH --cpus-per-task=1            # Cores per task (>1 if multithread tasks)
#SBATCH --mem=64G                     # Real memory (RAM) required per node
#SBATCH --time=00-00:30:00                 # Total run time limit (DD-HH:MM:SS)
#SBATCH --output=slurm.%N.%j.o     # STDOUT file for SLURM output
#SBATCH --error=slurm.%N.%j.err                 # STDERR file for Errors
#SBATCH --mail-user=rick.remsing@rutgers.edu
#SBATCH --mail-type=END

## Environment settings needed for this job
module purge
module load gcc/5.4 intel_mkl/16.0.3 openmpi/2.1.1 hdf5/1.8.16
source /projects/f_rcr78_1/PACKAGES/CP2K/cp2k/tools/toolchain/install/setup 
cp2k_bin=/projects/f_rcr78_1/PACKAGES/CP2K/cp2k/exe/local/cp2k.popt
input_file=agi-aimd.inp
output_file=agi.out
srun --mpi=openmpi $cp2k_bin -i $input_file -o $output_file
