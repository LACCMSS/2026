import numpy as np
import pandas as pd
import math
import scipy as sp
import os
import warnings
import ase
from ase.io import read, write
from ase.units import Bohr, Rydberg, kJ, kB, kcal, mol, fs, Angstrom, Hartree

Hartree_to_kcalpermol = Hartree * mol / kcal
Forces_HartreeperBohr_to_kcalpermolangstrom = Hartree_to_kcalpermol/ Bohr

GPa_to_eVperAngstromCube = 1/160.21766208
GPa_to_KcalpermoleperAngstromCube = 23.060541945329334/160.21766208

Bar_to_eVperAngstromCube = 1/1602176.6208
Bar_to_KcalpermoleperAngstromCube = 23.060541945329334/1602176.6208

def read_xyz_faster(filename, natoms=None, comment_symbol=None, readframes=None, savedevery=1):
    "Read AIMD/PIMD xyz Faster"
    print(f"Reading File {filename}") # Printing the filename
    with open(filename, 'r') as f:  # opening the file.
        if natoms is None: # If natoms is not set by the user then read the file to get natoms.
            natoms = int(f.readline().strip()) # reading in natoms.
        if comment_symbol is None:
            comment_symbol = list(f.readline().split()[0])[0]
            print(f" Please make sure there are no atom names in the trajectory begining with comment_symbol: {comment_symbol}. They won't be read.")
    complete_traj = {}  # Final traj to store the output.
    datatypes = {"atoms" : "str", "x" : np.float64, "y" : np.float64, "z" : np.float64} # Datatypes that we're gonna cast on the colums read from the file.
    if readframes is not None:
        nrowstoread = readframes*(natoms + 2)
    else:
        nrowstoread=None
    dataframe = pd.read_csv(filename, usecols=[0,1,2,3], delim_whitespace=True, names=['atoms','x','y','z'], nrows=nrowstoread, comment=comment_symbol).dropna() # Read in the file and drop columns with 3 or more than 3 NaN values.
    dataframe = dataframe.astype(dtype=datatypes)
    nframes = dataframe.shape[0] / natoms # Counting the total number of frames in the trajectory.
    dataframe_list = np.array_split(dataframe, nframes) # Splitting the dataframe into chunks containing nframe atoms i.e basically into frames.
    zeros = np.zeros(natoms, dtype=int) # Zeros for initializing molecule array.
    for counter, frame in enumerate(dataframe_list): # Iterating over the list containing frames.
        assert len(frame) == natoms, "Something went wrong"
        data = frame.reset_index() # reset index so as to start from zero again.
        data['index'] = np.arange(natoms) # Set the index column as atoms ranging from 0,1,2,3........natoms-1
        data.insert(1,'mols', zeros) # Insert the molecule array (only zeros right now)
        complete_traj[('').join(['time_',str(counter*savedevery)])] = data # Make the dictionary key as time_0, time_1, time_2....etc. etc.
        #if readframes is not None: #    if counter > readframes: break
    return complete_traj, natoms # Return the completed traj.

def forces_units(force_traj, units=1.0):
    forces_units = {}
    for time in force_traj:
        force_df = force_traj[time].copy(deep=True)
        force_df['x'] =  force_df['x'] * units
        force_df['y'] =  force_df['y'] * units
        force_df['z'] =  force_df['z'] * units
        forces_units[time] = force_df
    return forces_units

def read_energies_simple(file, units=None):
    energy = np.loadtxt(file, unpack=True)
    if units is not None:
        energy_list = list(energy * units)
    return energy_list

def extxyz_pos_force_writer(input_traj, force_traj, energies, stresses, atoms=None, xyzname="output.xyz", com_traj=False, box= [1.0, 1.0, 1.0]):
    """
    # I'm assuming that you kept the ordering of atoms same in both position and force traj.
    """
    if atoms is None:
        listdfs = list(input_traj.values())
        atoms = len(listdfs[0])
    if com_traj:
        atom_array = np.array(["A"]*atoms)
    else:
        atom_array = listdfs[0]['atoms'].to_numpy()
    str_array = np.zeros(atom_array.size, dtype=[('var1', 'U6'), ('var2', np.float64), ('var3', np.float64), ('var4', np.float64),     ('var5', np.float64), ('var6', np.float64), ('var7', np.float64)])
    with open(xyzname, 'a') as file:
        for counter, key in enumerate(input_traj):
            df = input_traj[key]
            df_force = force_traj[key]
            energy = energies[counter]
            stress1, stress2, stress3, stress4, stress5, stress6, stress7, stress8, stress9 = stresses[counter]
            file.write("{}\n".format(atoms))
            comment = f"Lattice=\"{box[0]} 0.0 0.0 0.0 {box[1]} 0.0 0.0 0.0 {box[2]}\" Properties=species:S:1:pos:R:3:forces:R:3 energy={energy} stress=\"{stress1} {stress2} {stress3} {stress4} {stress5} {stress6} {stress7} {stress8} {stress9}\" pbc=\"T T T\" Time={float(counter)}\n"
            file.write(comment) # "time = {}\n".format(counter))
            str_array['var1'] = atom_array
            str_array['var2'] = df['x'].to_numpy()
            str_array['var3'] = df['y'].to_numpy()
            str_array['var4'] = df['z'].to_numpy()
            str_array['var5'] = df_force['x'].to_numpy()
            str_array['var6'] = df_force['y'].to_numpy()
            str_array['var7'] = df_force['z'].to_numpy()
            np.savetxt(file, str_array, fmt='%5s %17.10f %17.10f %17.10f %17.10f %17.10f %17.10f')
            #if counter==2: break
    return None

def merge_multiple_trajs(**args):
    """
    Pass me multiple dictinary trajectories and I'll merge them in order without losing any frames.
    """
    out = {}
    item_list = []
    for item in args:
        item_list = list(item.values())
    for index, frame in enumerate(item_list):
        key = 'time_' + str(index)
        out[key] = frame
    return out

def read_stress(file, units=1):
    stress = np.loadtxt(file, usecols=range(2,11))
    stress = stress*units
    return stress
#------------------------------------------------------------------------------------------------------------------------------------------------------

#I used concat.sh to concat everything.
#Then next step are:

if __name__ == '__main__':
    pos, _ = read_xyz_faster("AgI-MD-pos-1.xyz", comment_symbol="i")
    forces, _ = read_xyz_faster("AgI-MD-frc-1.xyz", comment_symbol="i")
    En = read_energies_simple("AgI-MD-ener.dat", units=Hartree_to_kcalpermol)
    stress = read_stress("AgI-MD-1.stress", units=Bar_to_KcalpermoleperAngstromCube)
    print(len(En), len(pos))
    forces_kcalpermolang = forces_units(forces, units=Forces_HartreeperBohr_to_kcalpermolangstrom)
    extxyz_pos_force_writer(pos, forces_kcalpermolang, En, stresses=stress, box=[15.256499999999999, 15.256499999999999, 15.256499999999999], xyzname="AgI.extxyz")
