#!/usr/bin/env python
# coding: utf-8
import numpy as np
import pandas as pd
import math
from tqdm import tqdm
import matplotlib.pyplot as plt

from scipy import signal
import os, sys, time

#--------------------Parameters-----------------------------------
file_path = '.'
file_name = 'eql-unwrapped.xyz'
nframes = 80000
delta_t = 0.5
numAg = 54
numI = 54

def read_xyz_file(filename):
    datatypes = {"atoms" : "str", "x" : np.float64, "y" : np.float64, "z" : np.float64}
    dataframe = pd.read_csv(filename, usecols=[0,1,2,3], delim_whitespace=True, names=['atoms','x','y','z'], dtype=datatypes, on_bad_lines='skip', na_values=['='], comment='#').dropna()
    #dataframe = pd.read_csv(filename, usecols=[0,1,2,3], delim_whitespace=True, names=['atoms','x','y','z']).dropna()   #, dtype=datatypes
    cation_rows = dataframe[dataframe['atoms'] == 'Ag']
    anion_rows = dataframe[dataframe['atoms'] == 'I']
    cation_np = cation_rows[['x', 'y', 'z']].to_numpy()
    anion_np = anion_rows[['x', 'y', 'z']].to_numpy()
    cations = np.reshape(cation_np, (nframes, numAg, 3))
    anions = np.reshape(anion_np, (nframes, numI, 3))
    return cations, anions

def adjust_periodic(x,L):
    for i in range(len(x)-1):
        if x[i+1] - x[i] > L/2:
            x[i+1] -= (x[i+1] - x[i]+L/2)//L*L
        if x[i+1] - x[i] < -L/2:
            x[i+1] += (x[i] - x[i+1]+L/2)//L*L


def calc_msd_simple(x):
    n = len(x)
    msd = []
    for s in range(1,n//4):
        x2 = 0.0
        for i in range(n-s):
            x2 += (x[i+s]-x[i])**2
        x2 /= (n-s)
        msd.append(x2)
    return msd


def calc_msd_np(x):
    n = len(x)
    msd = []
    for s in range(1,n//4):
        dx = x[s:] - x[:-s]
        msd.append(np.average(dx**2))
    return msd

def calc_msd_fft(x):
    n=len(x)
    fk = np.fft.fft(x, n=2*n)
    power = fk * fk.conjugate()
    res = np.fft.ifft(power)[:n].real
    s2 = res/(n*np.ones(n)-np.arange(0,n))
    x2 = x**2
    s1 = np.zeros(n)
    s1[0] = np.average(x2)*2.0
    for m in range(1,n):
        s1[m] = np.average(x2[m:] + x2[:-m])
    msd = s1 - 2*s2
    return msd[:n//2]

def main(file_path, file_name):
    fname = os.path.join(file_path, file_name)

    print("Data-reading Started:")
    start = time.process_time()

    cations, anions = read_xyz_file(fname)

    read_data_time = time.process_time() - start

    print("\n".join(("\nData-reading Completed.",
                     "Used time: {:.5f} second.",
                     "The traj. has {:d} time-steps")).format(read_data_time,
                                                              len(cations)))

    parsing = time.process_time()

    #adjust_periodic_3d(cations,Lx, Ly, Lz)
    msd_cation = np.zeros(cations.shape[0]//2)
    msd_anion = np.zeros(anions.shape[0]//2)
    for i in range(cations.shape[1]):  # loop over particles
        for j in range(cations.shape[2]):  # loop over dimensions
            msd_cation += calc_msd_fft(cations[:,i,j])
            msd_anion += calc_msd_fft(anions[:,i,j])
    msd_c_average = msd_cation / (cations.shape[1])  #
    msd_a_average = msd_anion / (anions.shape[1])  #

    finish = time.process_time()
    print("Job Completed! Used time: {:.5f} second.".format(finish - parsing))

    return msd_c_average, msd_a_average


if __name__ == "__main__":
    msd_c, msd_a = main(file_path, file_name)
    timeseries = np.linspace(0,nframes*delta_t/1000/2, int(nframes/2))
    msd = np.vstack((timeseries, msd_c, msd_a)).transpose()

    np.savetxt('msd.dat', msd)
