#!/bin/bash
#SBATCH --clusters=amarel                       # Select which system(s) to use
#SBATCH --partition=cgpu                   # Partition (job queue)
#SBATCH --no-requeue                            # Return job to the queue if preempted
#SBATCH --job-name=Eql                   # Assign an short name to your job
#SBATCH --nodes=1                               # Number of nodes you require
#SBATCH --gres=gpu:2                 # Request number of GPUs
#SBATCH --nodelist=gpuc002                # Request number of GPUs
#SBATCH --ntasks=32                             # Total # of tasks across all nodes
#SBATCH --cpus-per-task=1                       # Cores per task (>1 if multithread tasks)
#SBATCH --mem=160G                              # Real memory (RAM) required per node
#SBATCH --time=0-30:00:00                         # Total run time limit (DD-HH:MM:SS)
#SBATCH --output=slurm.%N.%j.o                  # STDOUT file for SLURM output
#SBATCH --error=slurm.%N.%j.err                 # STDERR file for Errors

## Environment settings needed for this job

module purge
module load gcc/10.2.0-bz186
source /projects/f_rcr78_1/HSD/soft/cuda_env11.3
wait
module load gcc/10.2.0/openmpi/4.0.5-bz186
module load openblas/0.2.20-gc563
module load lapack/3.9.0-bz186
module load intel_mkl/18.0.5

export lmp=/projects/f_rcr78_1/HSD/soft/LAMMPS/lammps-Nequip/lammps-stable_29Sep2021/build/lmp

export OMP_NUM_THREADS=32
export CUDA_VISIBLE_DEVICES=0,1,2,3

$lmp -in in.nvt 
