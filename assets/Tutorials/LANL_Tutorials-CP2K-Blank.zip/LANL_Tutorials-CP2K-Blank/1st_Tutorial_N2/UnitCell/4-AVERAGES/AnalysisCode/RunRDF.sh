#!/bin/bash

time=`grep 'time' *pos*xyz | wc -l`
echo $time
sed -e "s/TTT/${time}/g" ../AnalysisCode/CalcRDF-template.f > CalcRDF.f
gfortran CalcRDF.f -o CalcRDF
./CalcRDF
