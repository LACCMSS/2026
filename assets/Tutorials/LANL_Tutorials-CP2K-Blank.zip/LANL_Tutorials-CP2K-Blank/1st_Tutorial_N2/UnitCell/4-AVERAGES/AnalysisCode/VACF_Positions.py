#!/usr/bin/env python3

#######   PLEASE READ THE FOLLOWING INSTRUCTION BEFORE RUNNING SCRIPT   #######
###                                                                         ###
###  NOTE: The position file needs to align before run total VACF script!!  ###
###                                                                         ###
###    The Format for Running This Script:                                  ###
###    ./VACF.py DIRECTORY_OF_YOUR_DATA INPUT_FILE DELTA_T OUTPUT_FILE      ###
###                                                                         ###
###    The values need to input manually when runing this script            ###
###                                                                         ###
###    (1) DIRECTORY_OF_YOUR_DATA: The path contains your data              ###
###                                                                         ###
###    (2) INPUT_FILE_NAME: The POSITION.xyz file                           ###
###                     (NOTE: do NOT need to re-split the Position file)   ###
###                                                                         ###
###    (3) DELTA_T: The Time_step set in simulation, in unit of fs          ###
###                                                                         ###
###    (4) OUTPUT_FILE_NAME: The Name of the Output File.                   ###
###                    (NOTE: do NOT need to type ">" sign!)                ###
###                                                                         ###
###############################################################################

from scipy import signal
import math
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import os, sys, time

file_path = sys.argv[1]
file_name = sys.argv[2]
delta_t = float(sys.argv[3])
outputf = sys.argv[4]

######## The constants will be used in this script ########
c = 2.9979245899e10 # speed of light in vacuum in [cm/s], from Wikipedia.

#### The functions will be used are listed as follows
def information(fname):
    ''' fetch the number of atoms and the elements information
    from the first block of the input file. It looks duplicate,
    but it would be more convenient for the following steps.
    '''

    elements = []
    with open(fname,'r') as fo:
        Natom = int(next(fo))
        next(fo)
        for i in range(Natom):
            line = next(fo)
            info = line.split()[0]
            elements.append(info)
    elements = np.array(elements)
    indices = np.where(elements)[0]
    return (Natom, elements, indices)


def screen_print(Natom, elements, indices):
    species = set(elements)
    fmt1 = "".join(("Number of atoms in this system: {:d}\n",
                    "There are {:d} kinds of elements, which are ",
                    "{:s}, " * len(species), "\n"))
    print(fmt1.format(Natom, len(species), *species))

    if len(elements) == 0:
        sys.exit("WARNING! No element! Please check the input file.")

def read_data(fname, Natom):
    with open(fname, 'r') as fo:
        timestep = 0
        coords = []

        for line in fo:
            try:
                next(fo)
            except StopIteration:
                break
            for n in range(Natom):
                line = next(fo)
                info = line.split()
                coords.append(info[1:])
            timestep += 1

        coords = np.asfarray(coords, dtype=np.float64).reshape(timestep,-1,3)
    return coords

def calc_derivative(array_1D, delta_t):
    ''' The derivatives of the angle_array were obtained by using the
    finite differences method.
    '''
    dy = np.gradient(array_1D)
    return np.divide(dy, delta_t)

def calc_ACF(array_1D):
    # Normalization
    yunbiased = array_1D - np.mean(array_1D, axis=0)
    ynorm = np.sum(np.power(yunbiased,2), axis=0)
#    print("the average value of input data array", ynorm)

    autocor = signal.fftconvolve(array_1D,
                                 array_1D[::-1],
                                 mode='full')[len(array_1D)-1:] / ynorm
    return autocor

def save_results(fout, time, intensity):
    with open(fout, "w") as fw:
        title = ("#Time", "VACF", "#ps", "a.u.")
        np.savetxt(fout, np.c_[time,intensity],
                   fmt="%10.5f %15.5e",
                   header="{0:>10}{1:>16}\n{2:^11}{3:^20}".format(*title),
                   comments='')

def main(file_path, file_name):
    """ The mian workflow:
    (1) read the coordinates of the selected atoms from file;
    (2) calculate the time derivative of the selected atoms (velocity);
    (3) calculate the velocity autocorrelation function of the selected atoms;
    (4) save the result to a txt file
    """
    fname = os.path.join(file_path, file_name)
    Natom, elements, indices = information(fname)
    screen_print(Natom, elements, indices)
    #mode, sel = select_atoms(selection_notes, Natom)
    #print("selected atoms:\n{:}".format(sel))

    print("Data-reading Started:")
    start = time.process_time()

    data = read_data(fname, Natom)
    #print "check point 01: data", data, np.shape(data)
    # data is a 3-D array contained coordinates of selected atoms in whole trajectory.
    read_data_time = time.process_time() - start

    print("\n".join(("\nData-reading Completed.",
                     "Used time: {:.5f} second.",
                     "The traj. has {:d} time-steps")).format(read_data_time,
                                                              len(data)))
    parsing = time.process_time()

    print("Program will deal with all atoms one by one.")
    for i in range(len(data[0,:,:])):
        print("\nThe atom {:d} has Completed.".format(i))
        normal_vectors = np.linalg.norm(data, axis=-1)
        print("#== The shape of the each atom array ==#", np.shape(normal_vectors[:,i]))
        derivative = calc_derivative(normal_vectors[:,i], delta_t)
        ACF_i = calc_ACF(derivative)
        if i == 0:
            ACF = ACF_i
        else:
            ACF += ACF_i
    print("\ncheck point 01: ACF = {:}\n{:}\n".format(ACF, np.shape(ACF)))

    intensity = ACF
    timepoints = np.arange(0,len(intensity)*delta_t,delta_t) #/1000   ### timepoints in ps
    print("\ncheck point 02: timestep = {:}\n{:}\n intensity = {:}\n{:}\n".format(timepoints, np.shape(timepoints), intensity, np.shape(intensity)))
    ### Normalized the intensity
    norm_intensity = intensity / intensity[0]

    #### save the results
    save_results(outputf, timepoints, intensity)
    finish = time.process_time()
    print("Job Completed! Used time: {:.5f} second.".format(finish - parsing))

######## The main program ########
if __name__ == "__main__":
    main(file_path, file_name)
