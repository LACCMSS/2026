gfortran msdblk.f -o msdblk -fPIC -mcmodel=large
