#!/bin/bash

run="1 2"

#for rr in $run ; do
	#cd Run$rr/
		time=`grep 'time' *pos*xyz | wc -l`
		echo $time
		sed -e "s/TTT/${time}/g" ../AnalysisCode/msdblk-template.f > msdblk.f
		cp ../AnalysisCode/CompileMSD.sh .
		bash CompileMSD.sh
		./msdblk
	#cd ../
#done
