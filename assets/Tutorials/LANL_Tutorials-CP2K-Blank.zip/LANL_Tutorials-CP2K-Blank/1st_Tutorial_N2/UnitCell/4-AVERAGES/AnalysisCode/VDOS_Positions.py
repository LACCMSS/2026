#!/usr/bin/env python3

#######   PLEASE READ THE FOLLOWING INSTRUCTION BEFORE RUNNING SCRIPT   #######
###                                                                         ###
###  NOTE: The position file needs to align before run total VACF script!!  ###
###                                                                         ###
###    The Format for Running This Script:                                  ###
###    ./VDOS.py DIRECTORY_OF_YOUR_DATA INPUT_FILE DELTA_T OUTPUT_FILE      ###
###                                                                         ###
###    The values need to input manually when runing this script            ###
###                                                                         ###
###    (1) DIRECTORY_OF_YOUR_DATA: The path contains your data              ###
###                                                                         ###
###    (2) INPUT_FILE_NAME: The POSITION.xyz file                           ###
###                     (NOTE: do NOT need to re-split the Position file)   ###
###                                                                         ###
###    (3) DELTA_T: The Time_step set in simulation, in unit of fs          ###
###                                                                         ###
###    (4) OUTPUT_FILE_NAME: The Name of the Output File.                   ###
###                    (NOTE: do NOT need to type ">" sign!)                ###
###                                                                         ###
###############################################################################


from scipy import signal
import math
import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import os, sys, time

file_path = sys.argv[1]
file_name = sys.argv[2]
delta_t = float(sys.argv[3]) * 1e-15
outputf = sys.argv[4]

######## The constants will be used in this script ########
c = 2.9979245899e10 # speed of light in vacuum in [cm/s], from Wikipedia.

#### The functions will be used are listed as follows
def information(fname):
    ''' fetch the number of atoms and the elements information
    from the first block of the input file. It looks duplicate,
    but it would be more convenient for the following steps.
    '''

    elements = []
    with open(fname,'r') as fo:
        Natom = int(next(fo))
        next(fo)
        for i in range(Natom):
            line = next(fo)
            info = line.split()[0]
            elements.append(info)
    elements = np.array(elements)
    indices = np.where(elements)[0]
    return (Natom, elements, indices)


def screen_print(Natom, elements, indices):
    species = set(elements)
    fmt1 = "".join(("Number of atoms in this system: {:d}\n",
                    "There are {:d} kinds of elements, which are ",
                    "{:s}, " * len(species), "\n"))
    print(fmt1.format(Natom, len(species), *species))

    if len(elements) == 0:
        sys.exit("WARNING! No element! Please check the input file.")

def read_data(fname, Natom):
    with open(fname, 'r') as fo:
        timestep = 0
        coords = []

        for line in fo:
            try:
                next(fo)
            except StopIteration:
                break
            for n in range(Natom):
                line = next(fo)
                info = line.split()
                coords.append(info[1:])
            timestep += 1

        coords = np.asfarray(coords, dtype=np.float64).reshape(timestep,-1,3)
    return coords

def calc_derivative(array_1D, delta_t):
    ''' The derivatives of the angle_array were obtained by using the
    finite differences method.
    '''
    dy = np.gradient(array_1D)
    return np.divide(dy, delta_t)

def zero_padding(sample_data):
    """ A series of Zeros will be padded to the end of the dipole moment
    array (before FFT performed), in order to obtain a array with the
    length which is the "next power of two" of numbers.

    #### Next power of two is calculated as: 2**math.ceil(math.log(x,2))
    #### or Nfft = 2**int(math.log(len(data_array)*2-1, 2))
    """
    return int(2 ** math.ceil(math.log(len(sample_data), 2)))

def calc_ACF(array_1D):
    # Normalization
    yunbiased = array_1D - np.mean(array_1D, axis=0)
    ynorm = np.sum(np.power(yunbiased,2), axis=0)
#    print("the average value of input data array", ynorm)

    autocor = signal.fftconvolve(array_1D,
                                 array_1D[::-1],
                                 mode='full')[len(array_1D)-1:] / ynorm
    return autocor

def calc_FFT(array_1D):
    """
    This function is for calculating the "intensity" of the ACF at each frequency
    by using the discrete fast Fourier transform.
    """
####
#### http://stackoverflow.com/questions/20165193/fft-normalization
####
    # A series of number of zeros will be padded to the end of the \
    # VACF array before FFT.
    N = zero_padding(array_1D)

    yfft = np.fft.fft(array_1D, N, axis=0) / len(array_1D)
#    yfft = np.fft.fft(data, n=int(N_fft), axis=0)/len(data) # no window func.
    print("shape of yfft {:}".format(np.shape(yfft)))
    return np.square(np.absolute(yfft))


def save_results(fout, wavenumber, intensity):
    with open(fout, "w") as fw:
        title = ("#Wavenumber", "VACF", "#ps", "a.u.")
        np.savetxt(fout, np.c_[wavenumber,intensity],
                   fmt="%10.5f %15.5e",
                   header="{0:>10}{1:>16}\n{2:^11}{3:^20}".format(*title),
                   comments='')

def main(file_path, file_name):
    fname = os.path.join(file_path, file_name)
    Natom, elements, indices = information(fname)
    screen_print(Natom, elements, indices)

    print("Data-reading Started:")
    start = time.process_time()

    data = read_data(fname, Natom)
    read_data_time = time.process_time() - start

    print("\n".join(("\nData-reading Completed.",
                     "Used time: {:.5f} second.",
                     "The traj. has {:d} time-steps")).format(read_data_time,
                                                              len(data)))

#    window = choose_window(data, window_function_name)
    parsing = time.process_time()

    print("Program will deal with all atoms one by one.")
    for i in range(len(data[0,:,:])):
        print("\nThe atom {:d} has Completed.".format(i))
        normal_vectors = np.linalg.norm(data, axis=-1)
        derivative = calc_derivative(normal_vectors[:,i], delta_t)
        ACF = calc_ACF(derivative)
        yfft_i = calc_FFT(ACF)
        if i == 0:
            yfft = yfft_i
        else:
            yfft += yfft_i
    print("\ncheck point 04: yfft = {:}\n{:}\n".format(yfft,
                                                           np.shape(yfft)))

    wavenumber = np.fft.fftfreq(len(yfft), delta_t * c)[0:int(len(yfft) / 2)]
    print(wavenumber)
    intensity = yfft[0:int(len(yfft)/2)]

    #### save the results
    save_results(outputf, wavenumber, intensity)
    finish = time.process_time()
    print("Job Completed! Used time: {:.5f} second.".format(finish - parsing))

######## The main program ########
if __name__ == "__main__":
    main(file_path, file_name)
