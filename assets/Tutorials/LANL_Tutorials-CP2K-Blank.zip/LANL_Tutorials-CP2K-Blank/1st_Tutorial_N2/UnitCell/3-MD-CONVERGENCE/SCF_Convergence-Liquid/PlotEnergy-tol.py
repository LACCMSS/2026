#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.cbook import get_sample_data
from pylab import *
from matplotlib.backends.backend_pdf import PdfPages
from scipy import interpolate
from matplotlib.offsetbox import TextArea,DrawingArea,OffsetImage,AnnotationBbox
import matplotlib.image as mpimg
import re
from scipy import *
import scipy.stats
import math
from scipy import optimize
#from matplotlib.ticker import FormatStrFormatter

matplotlib.rcParams.update({'font.size':12})

s1,t1,k1,temp1,pot1,E1,simt1 = np.loadtxt('eps_1E-7/N2-MD-1.ener', unpack=True)
s2,t2,k2,temp2,pot2,E2,simt2 = np.loadtxt('eps_1E-5/N2-MD-1.ener', unpack=True)
s3,t3,k3,temp3,pot3,E3,simt3 = np.loadtxt('eps_1E-3/N2-MD-1.ener', unpack=True)
#s4,t4,k4,temp4,pot4,E4,simt4 = np.loadtxt('eps_1E-1/N2-MD-1.ener', unpack=True)
#s5,t5,k5,temp5,pot5,E5,simt5 = np.loadtxt('dt_4.0/N2-MD-1.ener', unpack=True)




plt.figure(1,figsize=(3,2.5))
plt.subplots_adjust(hspace=0.25)
ax1 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("$E(t)-E(0)$",fontsize=22)
plt.xlabel("$t$ (${\\rm fs}$)",fontsize=22)
#plt.axis([1,1000,-0.5,1])
#plt.xticks([0,1000,2000,3000])
#plt.yticks([-0.1,-0.05,0,0.05,0.1])


colors=['#332288','#88CCEE','#117733','#DDCC77','#CC6677','#AA4499']

#plt.plot(t5-t5[0],E4-E5[0],'-',lw=1,label='convergence')
#plt.plot(t4-t4[0],E4-E4[0],'-',lw=1,label='1E-1')
plt.plot(t3-t3[0],E3-E3[0],'-',lw=1,label='1E-3')
plt.plot(t2-t2[0],E2-E2[0],'-',lw=1,label='1E-5')
plt.plot(t1-t1[0],E1-E1[0],'-',lw=1,label='1E-7')


plt.gca().xaxis.set_major_formatter(FormatStrFormatter('%g'))

plt.legend(ncol=1,shadow=True,prop={'size':8},loc=4)

pp=PdfPages('Energy-tol.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()




