#!/usr/bin/perl -W

@s=(0.775,0.800,0.825,0.850,0.875,0.900,0.925,0.950,0.975,1.000,1.025,1.050,1.075);

open(IN,"Energy_volume.dat");
while(<IN>)
{
	@tmp=split(/\s+/,$_);
	push(@E,$tmp[0]);
}
close(IN);

open(OUT,">Energy.dat");
for($i=0;$i<@E;$i++)
{
	print OUT "    $s[$i]    $E[$i]\n";
}
close(OUT);
