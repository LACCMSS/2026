eps=" "

template_file=Template/N2.inp
input_file=N2.inp
 
for ii in $eps ; do
    work_dir=eps_${ii}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -r $work_dir/*
    fi
    cp -r Template/* $work_dir/
    sed -e "s/LT_eps/${ii}/g" \
        $template_file > $work_dir/$input_file
done

