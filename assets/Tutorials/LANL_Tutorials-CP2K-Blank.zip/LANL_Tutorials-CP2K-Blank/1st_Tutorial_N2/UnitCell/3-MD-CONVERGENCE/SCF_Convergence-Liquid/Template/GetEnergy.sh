rm Energy_volume.dat
for ii in 0.775 0.800 0.825 0.850 0.875 0.900 0.925 0.950 0.975 1.000 1.025 1.050 1.075 
do
	grep 'ENERGY|' Cl2_${ii}.out | tail -n 1 | awk '{print $9}'>> Energy_volume.dat
done
perl PrintEnergyFile.pl
