!###################################################################
! CalcRDF.f
!
! This code will calculate RDFs
!
! R. Remsing, 2015
! Temple ICMS, CCDM
!
!###################################################################


! program start
      program CalcRDF
      
!#####################################
! Variable declaration
      
      integer i,j,k,l,m,n,iconf,id
      integer nconf,nskip,ntot
      integer natms,moatms,satms
      integer type
      integer nbinh,iH,iR,nbinR
      integer upb
      
      real*8 h,rrr,hhh,tstep
      real*8 dt
      real*8 lowr,highr,dr
      real*8 xij,yij,zij,hi,hj,rijsq
      real*8 rij(3),dist
      real*8 xtmp,ytmp,ztmp
      real*8 avgH, varH,tdens
      real*8 sum,pi,count
      real*8 a1,a2,a3,b1,b2,b3,c1,c2,c3
      real*8 d1,d2,d3,vol,dens,vardens
      real*8, ALLOCATABLE :: x(:),y(:),z(:)
      real*8, ALLOCATABLE :: gr(:)
      
      character(LEN=20) :: input,output
      character(LEN=80) :: title
      character(LEN=80) :: dummy
      character(LEN=4) :: junk
      
      pi = 3.14159265d0

      dt = 0.002d0
      
      dr = 0.05d0
      lowr=0.0d0
      highr=7.5d0
      nbinR = int( (highr-lowr)/dr )+1
      
      count = 0.0d0


!#####################################

! INPUT FILE
      input='N2-MD-pos-1.xyz'      
! NUMBER OF CONFIGURATIONS
      nconf = 4000
      nskip = 0
      ntot = nconf-nskip
      
      
!#####################################
! Read input
      write(*,*)'Initial input read...'
      open(99,FILE=input,STATUS='old')
      read(99,*)natms
      read(99,*)dummy
      close(99)
      write(*,*)'...Done'
           
! allocate arrays with size natms
      allocate(x(natms))
      allocate(y(natms))
      allocate(z(natms))
      allocate(gr(nbinR))
      
      do i=1,nbinR
       gr(i)=0.0d0
      enddo
      
      a1=0.3203086E+02*0.529177
      b2=0.3203086E+02*0.529177
      c3=0.3203086E+02*0.529177
      a2=0.0
      a3=0.0
      b1=0.0
      b3=0.0
      c1=0.0
      c2=0.0
      

!#####################################
! Read in configurations and calculate stuff
!#####################################
      
      write(*,*)'Analyzing...'
      
      
      open(13,FILE='densTimeSeries.dat')

      
      open(99,FILE=input,STATUS='old')
      dens=0.0d0
      vardens=0.0d0
      do iconf=1,nconf
        read(99,*)natms
        read(99,*)dummy 
	

	do i=1,natms
	 read(99,*)junk,x(i),y(i),z(i)
	enddo
	
	
!########################################################
! Now the positions are read in, let's calculate things #
!########################################################	
         
	if(iconf.gt.nskip)then
	  
	  ! Average volume
          d1 = b2*c3 - b3*c2
	  d2 = b3*c1 - b1*c3
	  d3 = b1*c2 - b2*c1
	  
	  vol=(a1*d1
     x     +a2*d2+a3*d3)	
	   
	   dens=dens+dble(natms)/vol
	   vardens = vardens+(dble(natms)/vol)**2
	   
	   
	   tdens=dble(natms)/vol
	   write(13,*)tdens
       
	  
	  
	  do i=1,natms-1
	   do j=i+1,natms
	    xij = x(j) - x(i)
	    yij = y(j) - y(i)
	    zij = z(j) - z(i)
	   
!#### Account for periodic boundary conditions
            xij=xij-nint(xij/a1)*a1
	    yij=yij-nint(yij/b2)*b2
	    zij=zij-nint(zij/c3)*c3

! accumulate incremental distances
            rij(1)=xij
	    rij(2)=yij
	    rij(3)=zij
	    
	    rijsq=0.0d0
	    do k=1,3
	      rijsq = rijsq + rij(k)**2
	    enddo
	    
	    dist = sqrt(rijsq)
	    
	    
	    iR = int( (dist-lowr)/dr )+1
	    if((iR.lt.nbinR).and.(iR.gt.0))then
	      gr(iR) = gr(iR) + 1.0d0
	      count = count + 1.0d0
	    endif	    
	    
	   enddo
          enddo

!#####################################
!### End if statement for nskip		      
       endif	    
!#####################################	    
! End loop over configurations
      enddo
      close(99)
      close(13)
 
      dens = dens/dble(ntot)
      vardens = vardens/dble(ntot) - dens**2
      
      write(*,*)'<rho_b> = ',dens
      write(*,*)'<(delta rho_b)^2> = ',vardens
      
      open(12,FILE='RDF.dat')
      do i=1,nbinR-1
      
       rrr = 0.5d0*( real(i-1)*dr
     x      +real(i)*dr+2.0d0*lowr )
       
       
       vol = 4.0d0*pi/3.0d0*(
     x (real(i)*dr+lowr)**3 - 
     x        (real(i-1)*dr+lowr)**3 )
       
       gr(i) = gr(i)/dble(natms)*2.0d0
     x   /dble(ntot)/vol/dens
     
!       gr(i) = gr(i)/count/vol
!     x  *dble(natms)/dens
     
       write(12,*) rrr,gr(i)
      enddo     
      close(12)


      
      stop
      end
























      
