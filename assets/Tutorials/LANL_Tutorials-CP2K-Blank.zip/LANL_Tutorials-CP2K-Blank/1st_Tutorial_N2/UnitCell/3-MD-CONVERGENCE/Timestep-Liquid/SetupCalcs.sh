dt=" "

template_file=Template/N2.inp
input_file=N2.inp
 
for ii in $dt ; do
    work_dir=dt_${ii}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -r $work_dir/*
    fi
    cp -r Template/* $work_dir/
    sed -e "s/LT_timestep/${ii}/g" \
        $template_file > $work_dir/$input_file
done

