scales=" "
rel_cutoff=
cutoff=
 
basis_file=BASIS_MOLOPT
potential_file=GTH_POTENTIALS
template_file=N2-template.inp
input_file=N2.inp
 
for ii in $scales ; do
    work_dir=scale_${ii}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -r $work_dir/*
    fi
    sed -e "s/LT_cutoff/${cutoff}/g" \
        -e "s/LT_rel_cutoff/${rel_cutoff}/g" \
	-e "s/LT_scale/${ii}/g" \
        $template_file > $work_dir/$input_file
    cp $basis_file $work_dir
    cp $potential_file $work_dir
done

