rel_cutoffs="10 20 30 40 50 60 70 80 90 100"

input_file=N2.inp
output_file=N2.out
no_proc_per_calc=2
no_proc_to_use=16

counter=1
for ii in $rel_cutoffs ; do
    work_dir=rel_cutoff_${ii}Ry
    cd $work_dir
    	if [ -f $output_file ] ; then
    	    rm $output_file
    	fi
	echo $work_dir
        touch testfile.txt
    cd ..
    counter=$(expr $counter + 1)
done
wait
