rm Energy_volume.dat Scales.txt
for ii in <INSERT SCALES HERE>
do
	grep 'ENERGY|' scale_${ii}/N2.out | tail -n 1 | awk '{print $9}'>> Energy_volume.dat
	echo $ii >> Scales.txt
done
perl PrintEnergyFile.pl
