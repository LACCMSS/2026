# Murnaghan Equation of State
f(x)=E0+K*V*( (1.0/(K2*(K2-1)))*(x/V)**(1.0-K2) + 1.0/K2*x/V - 1.0/(K2-1.0) )

# Initial guesses for parameters
K=1.0
K2=5.0
E0=-636.0
V=200.0

# Fit Energy as a function of volume to f(x)

fit f(x) 'Energy.dat' u ($1*5.856**3):2 via K,K2,E0,V

print K,K2,E0,V

set pointsize 3
set ylabel 'Energy'
set xlabel 'Volume'
p 'Energy.dat' u ($1*5.856**3):2 w p pt 6, f(x) lw 3
