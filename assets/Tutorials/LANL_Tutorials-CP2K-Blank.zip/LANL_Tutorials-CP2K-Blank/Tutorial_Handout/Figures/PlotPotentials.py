#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.cbook import get_sample_data
from pylab import *
from matplotlib.backends.backend_pdf import PdfPages
from scipy import interpolate
from scipy import special as sp
from matplotlib.offsetbox import TextArea,DrawingArea,OffsetImage,AnnotationBbox
import matplotlib.image as mpimg
from matplotlib import cm
from scipy.misc import derivative
import scipy.integrate as integrate

#plt.style('classic')

colors=['#4477AA','#CC6677','#800000','#44AA77','#7E7E7E']



r=arange(0.01,10,0.01)
v=np.zeros(len(r))
v0=np.zeros(len(r))
v1=np.zeros(len(r))
rho0=np.zeros(len(r))
rho1=np.zeros(len(r))
for i in range(0,len(r)):
	v[i] = 1.0/r[i]
	v0[i] = sp.erfc(r[i])/r[i]
	v1[i] = sp.erf(r[i])/r[i]
	rho1[i] = 1./(np.pi**(3./2.)) * exp(-r[i]**2)
	rho0[i] = 0. - 1./(np.pi**(3./2.)) * exp(-r[i]**2)

run0=np.zeros(len(r))
run1=np.zeros(len(r))
for i in range(1,len(r)):
	run0[i] = run0[i-1] + 4.*np.pi*(r[i] - r[i-1])*0.5*(r[i]**2*rho0[i]+r[i-1]**2*rho0[i-1]) 
	run1[i] = run1[i-1] + 4.*np.pi*(r[i] - r[i-1])*0.5*(r[i]**2*rho1[i]+r[i-1]**2*rho1[i-1])


rho0[0] = 100.


k=arange(0.01,10,0.01)
vk=np.zeros(len(k))
vk0=np.zeros(len(k))
vk1=np.zeros(len(k))
for i in range(0,len(k)):
	vk[i] = 4.*np.pi/k[i]**2
	vk1[i] = 4*np.pi/k[i]**2 * exp(-k[i]**2/4.)
	vk0[i] = vk[i] - vk1[i]




plt.figure(1,figsize=(4,3))
plt.subplots_adjust(hspace=0.25)
ax2 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("${\\rm Potential}$",fontsize=18)
plt.xlabel("${\\rm Distance \ (\sigma)}$",fontsize=18)
plt.axis([0,3,0,2.4])
plt.yticks([0,1,2])
plt.xticks([0,1,2,3])
#cmap = cm.Difference

p1,=plt.plot(r,v,'-',color=colors[4],lw=6)

vg1,=plt.plot(r,v0,'--',color=colors[2],lw=3)

vg2,=plt.plot(r,v1,'-',color=colors[0],lw=3)

plt.legend([p1,vg1,vg2],["$v$", "$v_0$","$v_1$"],
ncol=1,shadow=True,loc=1,prop={'size':14})

pp=PdfPages('Coulomb.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()






plt.figure(1,figsize=(4,3))
plt.subplots_adjust(hspace=0.25)
ax2 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("${\\rm Charge \ Density}$",fontsize=18)
plt.xlabel("${\\rm Distance \ (\sigma)}$",fontsize=18)
plt.axis([0,5,0,0.2])
#plt.yticks([0,1,2])
#plt.xticks([0,1,2,3])
#cmap = cm.Difference

#p1,=plt.plot(r,v,'-',color=colors[4],lw=6)

#vg1,=plt.plot(r,v0,'--',color=colors[2],lw=3)

vg2,=plt.plot(r,rho1,'-',color=colors[0],lw=5)

#plt.legend([p1,vg1,vg2],["$v$", "$v_0$","$v_1$"],
#ncol=1,shadow=True,loc=1,prop={'size':14})

pp=PdfPages('LongChargeDens.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()




plt.figure(1,figsize=(4,3))
plt.subplots_adjust(hspace=0.25)
ax2 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("${\\rm Charge \ Density}$",fontsize=18)
plt.xlabel("${\\rm Distance \ (\sigma)}$",fontsize=18)
plt.axis([0,5,-0.2,0.2])
#plt.yticks([0,1,2])
#plt.xticks([0,1,2,3])
#cmap = cm.Difference

#p1,=plt.plot(r,v,'-',color=colors[4],lw=6)

vg1,=plt.plot(r,rho0,'-',color=colors[2],lw=5)

#vg2,=plt.plot(r,rho1,'-',color=colors[0],lw=3)

#plt.legend([p1,vg1,vg2],["$v$", "$v_0$","$v_1$"],
#ncol=1,shadow=True,loc=1,prop={'size':14})

pp=PdfPages('ShortChargeDens.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()




plt.figure(1,figsize=(4,3))
plt.subplots_adjust(hspace=0.25)
ax2 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("${\\rm Total \ Charge}$",fontsize=18)
plt.xlabel("${\\rm Distance \ (\sigma)}$",fontsize=18)
plt.axis([0,5,-0,1])
#plt.yticks([0,1,2])
#plt.xticks([0,1,2,3])
#cmap = cm.Difference

#p1,=plt.plot(r,v,'-',color=colors[4],lw=6)

vg1,=plt.plot(r,1.+run0,'-',color=colors[2],lw=6)

vg2,=plt.plot(r,run1,'-',color=colors[0],lw=6)

plt.legend([vg1,vg2],["$\int \\rho_0$","$\int \\rho_1$"],
ncol=1,shadow=True,loc=1,prop={'size':14})

pp=PdfPages('RunInt.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()








plt.figure(1,figsize=(4,3))
plt.subplots_adjust(hspace=0.25)
ax2 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("${\\rm Coulomb \ Potential}$",fontsize=18)
plt.xlabel("${\\rm Wave \ Vector \ (1/\sigma)}$",fontsize=18)
plt.axis([0,10,0,10])
#plt.yticks([0,1,2])
#plt.xticks([0,1,2,3])
#cmap = cm.Difference

p1,=plt.plot(k,vk,'-',color=colors[4],lw=6)

#vg1,=plt.plot(r,v0,'--',color=colors[2],lw=3)

#vg2,=plt.plot(r,v1,'-',color=colors[0],lw=3)

#plt.legend([p1,vg1,vg2],["$v$", "$v_0$","$v_1$"],
#ncol=1,shadow=True,loc=1,prop={'size':14})

pp=PdfPages('Coulomb-Kspace.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()


plt.figure(1,figsize=(4,3))
plt.subplots_adjust(hspace=0.25)
ax2 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("${\\rm Potential}$",fontsize=18)
plt.xlabel("${\\rm Wave \ Vector \ (1/\sigma)}$",fontsize=18)
plt.axis([0,10,0,10])
#plt.yticks([0,1,2])
#plt.xticks([0,1,2,3])
#cmap = cm.Difference



p1,=plt.plot(k,vk,'--',color='0.7',lw=3,alpha=0.5)

#vg1,=plt.plot(r,v0,'--',color=colors[2],lw=3)

vg2,=plt.plot(k,vk1,'-',color=colors[0],lw=4)

plt.axvline(x = 1, ls='--',color = 'k', label = 'axvline - full height')


plt.legend([p1,vg2],["$\hat{\phi}$","$\hat{\phi}_1$"],
ncol=1,shadow=True,loc=1,prop={'size':14})

pp=PdfPages('Coulomb-KspaceLong.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()


plt.figure(1,figsize=(4,3))
plt.subplots_adjust(hspace=0.25)
ax2 = plt.subplot2grid((1,1),(0,0))
plt.ylabel("${\\rm Potential}$",fontsize=18)
plt.xlabel("${\\rm Wave \ Vector \ (1/\sigma)}$",fontsize=18)
plt.axis([0,10,0,10])
#plt.yticks([0,1,2])
#plt.xticks([0,1,2,3])
#cmap = cm.Difference


p1,=plt.plot(k,vk,'--',color='0.7',lw=3,alpha=0.5)

vg1,=plt.plot(r,vk0,'-',color=colors[2],lw=4)

#vg2,=plt.plot(k,vk1,'-',color=colors[0],lw=3)

plt.axvline(x = 1, ls='--',color = 'k', label = 'axvline - full height')

plt.legend([p1,vg1],["$\hat{\phi}$","$\hat{\phi}_0$"],
ncol=1,shadow=True,loc=1,prop={'size':14})

pp=PdfPages('Coulomb-KspaceShort.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()


