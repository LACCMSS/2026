#!/bin/bash
ecutrho_values=" "
ecutwfc=80

output_file=N2.out
plot_file=ecutrho_data.ssv

echo "# Density cutoff vs total energy (ecutwfc fixed at ${ecutwfc} Ry)" > $plot_file
echo "# Date: $(date)" >> $plot_file
echo "# ecutrho (Ry)  | Total Energy (Ry)  | Ratio ecutrho/ecutwfc" >> $plot_file

for ecutrho in $ecutrho_values ; do
    work_dir=ecutrho_${ecutrho}Ry
    total_energy=$(grep "!    total energy" $work_dir/$output_file | tail -1 | awk '{print $5}')
    ratio=$(awk "BEGIN {printf \"%.2f\", ${ecutrho} / ${ecutwfc}}")
    printf "%10.2f  %15.10f  %8.2f\n" $ecutrho $total_energy $ratio >> $plot_file
done
