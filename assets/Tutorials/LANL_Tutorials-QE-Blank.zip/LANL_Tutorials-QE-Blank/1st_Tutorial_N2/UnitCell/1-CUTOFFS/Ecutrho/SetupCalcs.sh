#!/bin/bash
# Fix ecutwfc at your converged value from Exercise 1 (default 80 Ry)
ecutwfc=80
ecutrho_values=" "

pseudo_file=N.pbe-n-kjpaw_psl.1.0.0.UPF
template_file=N2-template.in
input_file=N2.in

for ecutrho in $ecutrho_values ; do
    work_dir=ecutrho_${ecutrho}Ry
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -rf $work_dir/*
    fi
    sed -e "s/LT_ecutwfc/${ecutwfc}/g" \
        -e "s/LT_ecutrho/${ecutrho}/g" \
        $template_file > $work_dir/$input_file
    cp $pseudo_file $work_dir/ 2>/dev/null || echo "Note: download $pseudo_file with download_pseudos.sh"
done
