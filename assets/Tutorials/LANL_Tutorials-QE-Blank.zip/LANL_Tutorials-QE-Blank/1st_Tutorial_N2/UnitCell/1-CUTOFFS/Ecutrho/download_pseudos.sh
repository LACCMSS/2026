#!/bin/bash
# Download PAW pseudopotential for N from QE pslibrary 1.0.0, PBE functional
BASE_URL="https://pseudopotentials.quantum-espresso.org/upf_files"
for upf in N.pbe-n-kjpaw_psl.1.0.0.UPF ; do
    if [ ! -f $upf ] ; then
        echo "Downloading $upf..."
        wget -q "${BASE_URL}/${upf}" || curl -sO "${BASE_URL}/${upf}"
        echo "Done."
    else
        echo "$upf already present."
    fi
done
