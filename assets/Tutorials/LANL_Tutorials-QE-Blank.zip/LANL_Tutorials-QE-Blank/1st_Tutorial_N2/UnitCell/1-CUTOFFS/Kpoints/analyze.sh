#!/bin/bash
kpoint_values=" "

output_file=N2.out
plot_file=kpoints_data.ssv

echo "# K-point mesh vs total energy" > $plot_file
echo "# Date: $(date)" >> $plot_file
echo "# K-mesh (NxNxN)  | Total Energy (Ry)" >> $plot_file

for kpts in $kpoint_values ; do
    work_dir=kpts_${kpts}x${kpts}x${kpts}
    total_energy=$(grep "!    total energy" $work_dir/$output_file | tail -1 | awk '{print $5}')
    printf "%5dx%dx%d  %15.10f\n" $kpts $kpts $kpts $total_energy >> $plot_file
done
