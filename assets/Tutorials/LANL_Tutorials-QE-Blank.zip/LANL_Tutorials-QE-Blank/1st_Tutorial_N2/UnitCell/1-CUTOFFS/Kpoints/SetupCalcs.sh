#!/bin/bash
# Test k-point convergence: 1x1x1 (Gamma), 2x2x2, 3x3x3, 4x4x4
kpoint_values=" "

pseudo_file=N.pbe-n-kjpaw_psl.1.0.0.UPF
template_file=N2-template.in
input_file=N2.in

for kpts in $kpoint_values ; do
    work_dir=kpts_${kpts}x${kpts}x${kpts}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -rf $work_dir/*
    fi
    sed -e "s/LT_kpts/${kpts}/g" \
        $template_file > $work_dir/$input_file
    cp $pseudo_file $work_dir/ 2>/dev/null || echo "Note: download $pseudo_file with download_pseudos.sh"
done
