#!/bin/bash
#SBATCH --job-name=N2-kpts
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=00-01:00:00
#SBATCH --output=slurm.%N.%j.o
#SBATCH --error=slurm.%N.%j.err

module load quantumespresso
QE_BIN=pw.x

kpoint_values=" "

input_file=N2.in
output_file=N2.out

for kpts in $kpoint_values ; do
    work_dir=kpts_${kpts}x${kpts}x${kpts}
    cd $work_dir
    if [ -f $output_file ] ; then rm $output_file ; fi
    mpirun -np $SLURM_NTASKS $QE_BIN -in $input_file > $output_file
    cd ..
done
