#!/bin/bash
ecutwfc_values=" "

output_file=N2.out
plot_file=ecutwfc_data.ssv

echo "# Wavefunction cutoff vs total energy" > $plot_file
echo "# Date: $(date)" >> $plot_file
echo "# ecutrho = 4 * ecutwfc (PAW default)" >> $plot_file
echo "# ecutwfc (Ry)  | Total Energy (Ry)" >> $plot_file

for ecutwfc in $ecutwfc_values ; do
    work_dir=ecutwfc_${ecutwfc}Ry
    total_energy=$(grep "!    total energy" $work_dir/$output_file | tail -1 | awk '{print $5}')
    printf "%10.2f  %15.10f\n" $ecutwfc $total_energy >> $plot_file
done
