#!/bin/bash
#SBATCH --job-name=N2-ecutwfc
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=00-01:00:00
#SBATCH --output=slurm.%N.%j.o
#SBATCH --error=slurm.%N.%j.err

module load quantumespresso   # adjust for your cluster
QE_BIN=pw.x                   # or full path, e.g. /path/to/pw.x

ecutwfc_values=" "

input_file=N2.in
output_file=N2.out

for ecutwfc in $ecutwfc_values ; do
    work_dir=ecutwfc_${ecutwfc}Ry
    cd $work_dir
    if [ -f $output_file ] ; then rm $output_file ; fi
    mpirun -np $SLURM_NTASKS $QE_BIN -in $input_file > $output_file
    cd ..
done
