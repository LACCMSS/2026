#!/usr/bin/env python3
"""
Plot energy conservation vs time for different SCF convergence thresholds.
Run after all conv_* simulations have completed.
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import os

matplotlib.rcParams.update({'font.size': 12})

def extract_econs(outfile):
    energies = []
    with open(outfile) as f:
        for line in f:
            if 'Ekin + Etot' in line:
                try:
                    energies.append(float(line.split()[-2]))
                except (ValueError, IndexError):
                    pass
    return np.array(energies)

dt_fs = 0.5  # timestep used in these simulations

# Directories and labels - adjust to match your runs
runs = [
    ('conv_1E-3', '1e-3'),
    ('conv_1E-5', '1e-5'),
    ('conv_1E-7', '1e-7'),
    ('conv_1E-9', '1e-9'),
]

colors = ['#332288', '#88CCEE', '#117733', '#DDCC77', '#CC6677']

fig, ax = plt.subplots(figsize=(3, 2.5))

for i, (d, label) in enumerate(runs):
    outfile = os.path.join(d, 'N2-MD.out')
    if not os.path.exists(outfile):
        print(f"Skipping {d}: output not found")
        continue
    E = extract_econs(outfile)
    if len(E) == 0:
        print(f"No energy data in {d}")
        continue
    t = np.arange(1, len(E) + 1) * dt_fs
    ax.plot(t - t[0], E - E[0], '-', lw=1, color=colors[i % len(colors)],
            label=f'conv\\_thr={label}')

ax.set_ylabel('$E(t)-E(0)$ (Ry)', fontsize=14)
ax.set_xlabel('$t$ (fs)', fontsize=14)
ax.legend(ncol=1, prop={'size': 8}, loc='upper left', bbox_to_anchor=(1.02, 1.0), borderaxespad=0.0)

pp = PdfPages('Energy-tol.pdf')
fig.savefig(pp, format='pdf', bbox_inches='tight')
pp.close()
print("Saved Energy-tol.pdf")
