#!/bin/bash
# conv_thr values in Ry: choose 3-5 values spanning several orders of magnitude
# e.g. 1e-3 1e-5 1e-7 1e-9 (QE conv_thr ~ EPS_SCF_CP2K * n_electrons)
conv_thr_values=" "

pseudo_file=N.pbe-n-kjpaw_psl.1.0.0.UPF
template_file=Template/N2.in
input_file=N2.in

for thr in $conv_thr_values ; do
    # Format for directory name: replace 'e-' with 'E-'
    dir_name=$(echo $thr | sed 's/e-/E-/g' | sed 's/e+/E+/g')
    work_dir=conv_${dir_name}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -rf $work_dir/*
    fi
    sed -e "s/LT_conv_thr/${thr}/g" \
        $template_file > $work_dir/$input_file
    cp Template/$pseudo_file $work_dir/ 2>/dev/null || echo "Note: run Template/download_pseudos.sh first"
done
