#!/bin/bash
#SBATCH --job-name=N2-scf
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=00-01:00:00
#SBATCH --output=slurm.%N.%j.o
#SBATCH --error=slurm.%N.%j.err

module load quantumespresso
QE_BIN=pw.x

conv_thr_values=" "

input_file=N2.in
output_file=N2-MD.out

for thr in $conv_thr_values ; do
    dir_name=$(echo $thr | sed 's/e-/E-/g' | sed 's/e+/E+/g')
    work_dir=conv_${dir_name}
    cd $work_dir
    if [ -f $output_file ] ; then rm $output_file ; fi
    mpirun -np $SLURM_NTASKS $QE_BIN -in $input_file > $output_file
    cd ..
done
