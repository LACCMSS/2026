#!/bin/bash
# Timestep values in fs - choose 3-5 values between 0.1 and 5.0 fs
timesteps=" "

pseudo_file=N.pbe-n-kjpaw_psl.1.0.0.UPF
template_file=Template/N2.in
input_file=N2.in

for dt_fs in $timesteps ; do
    # Convert fs to Rydberg atomic units (1 fs = 1/0.04838 a.u.)
    dt_au=$(awk "BEGIN {printf \"%.4f\", ${dt_fs} / 0.04838}")
    work_dir=dt_${dt_fs}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -rf $work_dir/*
    fi
    sed -e "s/LT_dt_au/${dt_au}/g" \
        $template_file > $work_dir/$input_file
    cp Template/$pseudo_file $work_dir/ 2>/dev/null || echo "Note: run Template/download_pseudos.sh first"
done
