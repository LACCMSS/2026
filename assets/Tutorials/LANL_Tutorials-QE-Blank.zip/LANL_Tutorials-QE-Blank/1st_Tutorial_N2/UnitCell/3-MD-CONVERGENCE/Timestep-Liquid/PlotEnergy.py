#!/usr/bin/env python3
"""
Plot energy conservation vs time and vs timestep for QE BOMD runs.
Run after all dt_* simulations have completed.
Uses: dt_0.1/N2-MD.out, dt_0.5/N2-MD.out, dt_1.0/N2-MD.out (adjust as needed).
"""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import glob, os, re

matplotlib.rcParams.update({'font.size': 12})

def extract_econs(outfile):
    """Extract conserved energy (Ekin+Etot) time series from QE MD output."""
    energies = []
    with open(outfile) as f:
        for line in f:
            if 'Ekin + Etot' in line:
                try:
                    energies.append(float(line.split()[-2]))
                except (ValueError, IndexError):
                    pass
    return np.array(energies)

# Directories and timestep labels - add/remove entries to match your runs
runs = [
    ('dt_0.1', 0.1),
    ('dt_0.5', 0.5),
    ('dt_1.0', 1.0),
]

colors = ['#332288', '#88CCEE', '#117733', '#DDCC77', '#CC6677']

fig1, ax1 = plt.subplots(figsize=(3, 2.5))
fig2, ax2 = plt.subplots(figsize=(3, 2.5))

for i, (d, dt_fs) in enumerate(runs):
    outfile = os.path.join(d, 'N2-MD.out')
    if not os.path.exists(outfile):
        print(f"Skipping {d}: output not found")
        continue
    E = extract_econs(outfile)
    if len(E) == 0:
        print(f"No energy data in {d}")
        continue
    t = np.arange(1, len(E) + 1) * dt_fs
    label = f'$\\Delta t={dt_fs}$ fs'
    ax1.plot(t - t[0], E - E[0], '-', lw=1, color=colors[i % len(colors)], label=label)
    ax2.plot(np.arange(len(E)), E - E[0], '-', lw=1, color=colors[i % len(colors)], label=label)

ax1.set_ylabel('$E(t)-E(0)$ (Ry)', fontsize=14)
ax1.set_xlabel('$t$ (fs)', fontsize=14)
ax1.legend(ncol=1, prop={'size': 8}, loc='upper left', bbox_to_anchor=(1.02, 1.0), borderaxespad=0.0)

ax2.set_ylabel('$E(t)-E(0)$ (Ry)', fontsize=14)
ax2.set_xlabel('Timestep', fontsize=14)
ax2.legend(ncol=1, prop={'size': 8}, loc='upper left', bbox_to_anchor=(1.02, 1.0), borderaxespad=0.0)

pp = PdfPages('Energy.pdf')
fig1.savefig(pp, format='pdf', bbox_inches='tight')
pp.close()

pp = PdfPages('Energy-steps.pdf')
fig2.savefig(pp, format='pdf', bbox_inches='tight')
pp.close()

print("Saved Energy.pdf and Energy-steps.pdf")
