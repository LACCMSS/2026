#!/bin/bash
# Compute radial distribution function from QE MD output.
# 1. Extract trajectory to XYZ format (creates N2-MD-pos-1.xyz)
# 2. Compile and run CalcRDF.f -> RDF.dat

QE_OUTPUT=N2-MD.out
TRAJ_FILE=N2-MD-pos-1.xyz
DT_FS=1.0   # set to match your simulation timestep

# Extract trajectory from QE output
if [ ! -f $TRAJ_FILE ]; then
    echo "Extracting trajectory from $QE_OUTPUT..."
    python ../AnalysisCode/extract_traj.py $QE_OUTPUT $TRAJ_FILE $DT_FS
fi

# Count frames (header lines contain 'time')
nframes=$(grep 'time' $TRAJ_FILE | wc -l)
echo "Number of frames: $nframes"

# Build CalcRDF.f from template and compile
sed -e "s/TTT/${nframes}/g" ../AnalysisCode/CalcRDF-template.f > CalcRDF.f
gfortran CalcRDF.f -o CalcRDF
./CalcRDF
