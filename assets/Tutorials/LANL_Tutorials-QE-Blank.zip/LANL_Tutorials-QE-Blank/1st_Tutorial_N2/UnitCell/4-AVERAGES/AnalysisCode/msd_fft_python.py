#!/usr/bin/env python
# coding: utf-8
import numpy as np
import pandas as pd
import math
from tqdm import tqdm
import matplotlib.pyplot as plt

from scipy import signal
import os, sys, time

#--------------------Parameters-----------------------------------
file_path = '.'
file_name = 'N2-MD-pos-1.xyz'
nframes = None   # auto-detected from trajectory
delta_t = 1.0
numN = 8

def read_xyz_file(filename):
    global nframes
    dataframe = pd.read_csv(filename, usecols=[0,1,2,3], delim_whitespace=True,
                            names=['atoms','x','y','z'], dtype=str,
                            on_bad_lines='skip', comment='#')
    for c in ('x','y','z'):
        dataframe[c] = pd.to_numeric(dataframe[c], errors='coerce')
    dataframe = dataframe.dropna()
    cation_rows = dataframe[dataframe['atoms'] == 'N']
    cation_np = cation_rows[['x', 'y', 'z']].to_numpy()
    nframes = cation_np.shape[0] // numN
    cations = np.reshape(cation_np[:nframes*numN], (nframes, numN, 3))
    return cations

def adjust_periodic(x,L):
    for i in range(len(x)-1):
        if x[i+1] - x[i] > L/2:
            x[i+1] -= (x[i+1] - x[i]+L/2)//L*L
        if x[i+1] - x[i] < -L/2:
            x[i+1] += (x[i] - x[i+1]+L/2)//L*L


def calc_msd_simple(x):
    n = len(x)
    msd = []
    for s in range(1,n//4):
        x2 = 0.0
        for i in range(n-s):
            x2 += (x[i+s]-x[i])**2
        x2 /= (n-s)
        msd.append(x2)
    return msd


def calc_msd_np(x):
    n = len(x)
    msd = []
    for s in range(1,n//4):
        dx = x[s:] - x[:-s]
        msd.append(np.average(dx**2))
    return msd

def calc_msd_fft(x):
    n=len(x)
    fk = np.fft.fft(x, n=2*n)
    power = fk * fk.conjugate()
    res = np.fft.ifft(power)[:n].real
    s2 = res/(n*np.ones(n)-np.arange(0,n))
    x2 = x**2
    s1 = np.zeros(n)
    s1[0] = np.average(x2)*2.0
    for m in range(1,n):
        s1[m] = np.average(x2[m:] + x2[:-m])
    msd = s1 - 2*s2
    return msd[:n//2]

def main(file_path, file_name):
    fname = os.path.join(file_path, file_name)

    print("Data-reading Started:")
    start = time.process_time()

    cations = read_xyz_file(fname)

    read_data_time = time.process_time() - start

    print("\n".join(("\nData-reading Completed.",
                     "Used time: {:.5f} second.",
                     "The traj. has {:d} time-steps")).format(read_data_time,
                                                              len(cations)))

    parsing = time.process_time()

    #adjust_periodic_3d(cations,Lx, Ly, Lz)
    msd_cation = np.zeros(cations.shape[0]//2)
    for i in range(cations.shape[1]):  # loop over particles
        for j in range(cations.shape[2]):  # loop over dimensions
            msd_cation += calc_msd_fft(cations[:,i,j])
    msd_c_average = msd_cation / (cations.shape[1])  #

    finish = time.process_time()
    print("Job Completed! Used time: {:.5f} second.".format(finish - parsing))

    return msd_c_average


if __name__ == "__main__":
    msd_c = main(file_path, file_name)
    n = len(msd_c)
    timeseries = np.arange(n) * delta_t / 1000.0   # ps
    msd = np.vstack((timeseries, msd_c)).transpose()
    np.savetxt('msd.dat', msd, header='time[ps]  MSD[Ang^2]')
    print("Wrote msd.dat (%d points)" % n)
