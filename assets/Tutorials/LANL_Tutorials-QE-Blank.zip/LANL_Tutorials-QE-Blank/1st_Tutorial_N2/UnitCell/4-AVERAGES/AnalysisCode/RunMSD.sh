#!/bin/bash
# Compute mean squared displacement from QE MD output.

QE_OUTPUT=N2-MD.out
TRAJ_FILE=N2-MD-pos-1.xyz
DT_FS=1.0

if [ ! -f $TRAJ_FILE ]; then
    echo "Extracting trajectory from $QE_OUTPUT..."
    python ../AnalysisCode/extract_traj.py $QE_OUTPUT $TRAJ_FILE $DT_FS
fi

nframes=$(grep 'time' $TRAJ_FILE | wc -l)
echo "Number of frames: $nframes"

sed -e "s/TTT/${nframes}/g" ../AnalysisCode/msdblk-template.f > msdblk.f
cp ../AnalysisCode/CompileMSD.sh .
bash CompileMSD.sh
./msdblk
