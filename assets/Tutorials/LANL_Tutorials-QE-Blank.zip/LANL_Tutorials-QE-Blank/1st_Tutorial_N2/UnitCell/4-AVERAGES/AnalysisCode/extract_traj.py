#!/usr/bin/env python3
"""
Extract XYZ trajectory (Cartesian Angstrom) from QE pw.x MD output.

Usage: python extract_traj.py <qe_output_file> <xyz_output_file> [dt_fs]

Writes XYZ file with headers:  i = N, time = T.TTT fs
Compatible with RunRDF.sh (greps 'time' to count frames) and VACF/VDOS scripts.

QE prints ATOMIC_POSITIONS during MD in the *input* units (crystal, bohr, alat,
or angstrom). The downstream analysis codes (CalcRDF.f, msdblk.f, VACF/VDOS)
expect Cartesian Angstrom, so this script converts to Cartesian Angstrom using
the cell parsed from the QE output.
"""
import sys
import re

BOHR = 0.52917721  # Angstrom per Bohr


def parse_cell_ang(content):
    """Return the 3x3 cell (rows = lattice vectors) in Angstrom, or None."""
    m = re.search(
        r'CELL_PARAMETERS\s*\(([^)]*)\)\s*\n'
        r'\s*([-\d.eE]+)\s+([-\d.eE]+)\s+([-\d.eE]+)\s*\n'
        r'\s*([-\d.eE]+)\s+([-\d.eE]+)\s+([-\d.eE]+)\s*\n'
        r'\s*([-\d.eE]+)\s+([-\d.eE]+)\s+([-\d.eE]+)', content)
    if m:
        unit = m.group(1).strip().lower()
        v = [float(x) for x in m.groups()[1:]]
        cell = [v[0:3], v[3:6], v[6:9]]
        if 'bohr' in unit:
            cell = [[c * BOHR for c in row] for row in cell]
        elif 'alat' in unit:
            am = re.search(r'lattice parameter \(alat\)\s*=\s*([\d.]+)', content)
            alat = float(am.group(1)) * BOHR if am else 1.0
            cell = [[c * alat for c in row] for row in cell]
        return cell
    # Fallback: alat + "crystal axes" block (ibrav != 0)
    am = re.search(r'lattice parameter \(alat\)\s*=\s*([\d.]+)', content)
    ax = re.search(
        r'crystal axes:.*\n'
        r'\s*a\(1\)\s*=\s*\(\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*\)\s*\n'
        r'\s*a\(2\)\s*=\s*\(\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*\)\s*\n'
        r'\s*a\(3\)\s*=\s*\(\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*\)', content)
    if am and ax:
        alat = float(am.group(1)) * BOHR
        v = [float(x) for x in ax.groups()]
        return [[v[0] * alat, v[1] * alat, v[2] * alat],
                [v[3] * alat, v[4] * alat, v[5] * alat],
                [v[6] * alat, v[7] * alat, v[8] * alat]]
    return None


def to_cartesian(r, unit, cell, content):
    if unit.startswith('crystal'):
        if cell is None:
            sys.exit("ERROR: crystal coordinates but no cell found in output")
        x = r[0] * cell[0][0] + r[1] * cell[1][0] + r[2] * cell[2][0]
        y = r[0] * cell[0][1] + r[1] * cell[1][1] + r[2] * cell[2][1]
        z = r[0] * cell[0][2] + r[1] * cell[1][2] + r[2] * cell[2][2]
        return x, y, z
    if unit.startswith('bohr'):
        return r[0] * BOHR, r[1] * BOHR, r[2] * BOHR
    if unit.startswith('alat'):
        am = re.search(r'lattice parameter \(alat\)\s*=\s*([\d.]+)', content)
        alat = float(am.group(1)) * BOHR if am else 1.0
        return r[0] * alat, r[1] * alat, r[2] * alat
    return r[0], r[1], r[2]  # angstrom


def extract_xyz(qe_out, xyz_out, dt_fs=1.0):
    with open(qe_out) as f:
        content = f.read()

    # species printed at column 0 in QE output (no leading whitespace)
    pattern = re.compile(
        r'ATOMIC_POSITIONS\s*\(([^)]*)\)\n'
        r'((?:[ \t]*\S+[ \t]+[-\d.]+[ \t]+[-\d.]+[ \t]+[-\d.]+\n)+)'
    )
    matches = pattern.findall(content)
    if not matches:
        print(f"ERROR: No ATOMIC_POSITIONS found in {qe_out}")
        sys.exit(1)

    cell = parse_cell_ang(content)
    nat = len(matches[0][1].strip().split('\n'))

    with open(xyz_out, 'w') as f:
        for i, (unit, block) in enumerate(matches):
            unit = unit.strip().lower()
            t = (i + 1) * dt_fs
            f.write(f'{nat}\n')
            f.write(f' i = {i+1:8d}, time = {t:14.3f} fs\n')
            for line in block.strip().split('\n'):
                p = line.split()
                r = [float(p[1]), float(p[2]), float(p[3])]
                x, y, z = to_cartesian(r, unit, cell, content)
                f.write(f'{p[0]}  {x:.8f}  {y:.8f}  {z:.8f}\n')

    print(f"Extracted {len(matches)} frames ({nat} atoms each) to {xyz_out}")


if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python extract_traj.py <qe_output_file> <xyz_output_file> [dt_fs]")
        sys.exit(1)
    dt = float(sys.argv[3]) if len(sys.argv) >= 4 else 1.0
    extract_xyz(sys.argv[1], sys.argv[2], dt)
