#!/usr/bin/env python3
"""
Extract MD thermodynamic data from QE pw.x output and write .ener file.

Usage: python make_ener_file.py <qe_output_file> <ener_output_file> <dt_fs>

Output columns (compatible with original ComputeTemperatureFlucs.py):
  step  time[fs]  Ekin[Ry]  T[K]  Epot[Ry]  Econs[Ry]  0.0

Note: Energies are in Ry (QE native units). ComputeTemperatureFlucs.py uses
only the temperature column for heat capacity; energy columns are for plotting
relative changes (unit-agnostic for delta-E plots).
"""
import sys
import re

def make_ener(qe_out, ener_out, dt_fs):
    with open(qe_out) as f:
        content = f.read()

    ekins = [float(x) for x in re.findall(
        r'kinetic energy \(ekin\)\s*=\s*([-\d.]+)\s*Ry', content, re.IGNORECASE)]
    temps = [float(x) for x in re.findall(
        r'temperature\s*=\s*([-\d.]+)\s*K', content, re.IGNORECASE)]
    epots = [float(x) for x in re.findall(
        r'!\s+total energy\s+=\s+([-\d.]+)\s*Ry', content)]
    econs = [float(x) for x in re.findall(
        r'Ekin \+ Etot \(const\)\s*=\s*([-\d.]+)\s*Ry', content)]

    n = min(len(ekins), len(temps), len(epots), len(econs))
    if n == 0:
        print(f"ERROR: No MD data found in {qe_out}")
        sys.exit(1)

    with open(ener_out, 'w') as f:
        f.write('#    Step    Time[fs]       Ekin[Ry]        T[K]       Epot[Ry]      Econs[Ry]  CPUtime\n')
        for i in range(n):
            step = i + 1
            t = step * dt_fs
            f.write(f'  {step:6d}  {t:10.5f}  {ekins[i]:14.8f}  {temps[i]:10.4f}'
                    f'  {epots[i]:14.8f}  {econs[i]:14.8f}  0.0\n')

    print(f"Wrote {n} steps to {ener_out}")

if __name__ == '__main__':
    if len(sys.argv) != 4:
        print("Usage: python make_ener_file.py <qe_output_file> <ener_output_file> <dt_fs>")
        sys.exit(1)
    make_ener(sys.argv[1], sys.argv[2], float(sys.argv[3]))
