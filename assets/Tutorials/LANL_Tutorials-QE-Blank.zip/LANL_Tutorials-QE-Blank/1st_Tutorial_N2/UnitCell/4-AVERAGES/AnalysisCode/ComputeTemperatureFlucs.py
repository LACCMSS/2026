#!/usr/bin/env python

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.cbook import get_sample_data
from pylab import *
from matplotlib.backends.backend_pdf import PdfPages
from scipy import interpolate
from matplotlib.offsetbox import TextArea,DrawingArea,OffsetImage,AnnotationBbox
import matplotlib.image as mpimg
import re
from scipy import *
import scipy.stats
import math
from scipy import optimize
from matplotlib.ticker import FormatStrFormatter

matplotlib.rcParams.update({'font.size':12})

s1,t1,k1,temp1,pot1,E1,simt1 = np.loadtxt('N2-MD-1.ener', unpack=True)

avgT=0.0
varT=0.0
for i in range(0,len(temp1)):
	avgT += temp1[i]
	varT += temp1[i]**2
avgT/=len(temp1)
varT = varT/len(temp1) - avgT**2

Nmol = 4.0

CvNkB = 3.0/2.0/(1.0 - 3.0*Nmol/2.*varT/avgT**2)

print("<T> = ",avgT, " K")
print("<(delta T)^2> = ",varT, " K^2")
print("C_v / N k_B = ", CvNkB)






plt.figure(1,figsize=(3,2.5))
plt.subplots_adjust(hspace=0.25)
ax1 = plt.subplot2grid((1,1),(0,0))
#plt.ylabel("$T(t)$ (K)",fontsize=22)
plt.xlabel("$t$ (${\\rm fs}$)",fontsize=22)
#plt.axis([1,1000,-0.5,1])
plt.xticks([0,1000,2000,3000])
#plt.yticks([-0.1,-0.05,0,0.05,0.1])

colors=['#332288','#88CCEE','#117733','#DDCC77','#CC6677','#AA4499']


at = avgT+t1*0.0
ax1.fill_between(t1-t1[0],at-sqrt(varT)/2.0,at+sqrt(varT)/2.0, facecolor='k',alpha=0.5,edgecolor='None',)
plt.plot(t1-t1[0],at,'-',color='k',lw=2,label='$\left<T\\right>$ (K)')

plt.plot(t1-t1[0],temp1,'-',lw=1,color='r',label='$T(t)$ (K)')


plt.gca().xaxis.set_major_formatter(FormatStrFormatter('%g'))

plt.legend(ncol=1,shadow=True,prop={'size':8},loc='upper left',bbox_to_anchor=(1.02,1.0),borderaxespad=0.0)


pp=PdfPages('Temperature.pdf')
plt.savefig(pp,format='pdf',bbox_inches='tight')
pp.close()
