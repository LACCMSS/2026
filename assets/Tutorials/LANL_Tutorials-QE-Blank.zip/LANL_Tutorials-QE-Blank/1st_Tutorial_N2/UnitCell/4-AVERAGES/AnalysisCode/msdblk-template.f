      program msdblk
c*********************************************************************
c
c     dl_poly program to calculate mean square displacement
c     for selected atoms from dl_poly HISTORY file
c     this version incorporates a blocking average method
c     to calculate the statistical error
c
c     copyright daresbury laboratory 1996
c     author  w.smith jan 1996
c
c     wl
c     1997/02/20 14:47:11
c     1.1
c     Exp
c
c*********************************************************************

      implicit real*8(a-h,o-z)

      parameter (mxatms=5000,npts=70000,nstr=10000,ndeg=3
     x   ,mxconf=70000)
      character*1 fmt
      character*8 atname
      character*40 fname
      character*80 title
      character*8 atmnam(mxatms)
      real*8 msd(npts,mxconf),msd0(npts,nstr,3),sig(ndeg)
      dimension xxx(mxatms),yyy(mxatms),zzz(mxatms)
      dimension weight(mxatms),chge(mxatms)
      dimension avcell(9),cell(9),rcell(9)
      dimension xx0(nstr),yy0(nstr),zz0(nstr)
      dimension xx1(nstr),yy1(nstr),zz1(nstr)
      dimension acx(nstr),acy(nstr),acz(nstr)
      dimension imd(npts),msm(npts)

c     open the I/O files

c      open(5,file='msd_input')
      open(6,file='msd_output')

      write(6,'(a)')
     x  '# Mean Square Displacement Blocking Program'

c     read the control variables
      fname='N2-MD-pos-1.xyz'
      natms=8
      tstep=0.001
      nconf=TTT
      nmsd=TTT
      isampl=1
      iomsd=1
      nmg=7




c     name of atomic species for autocorrelation
c      read(5,*)atname

c     name of selected HISTORY file
c      read(5,*)fname

c     HISTORY file formatted or unformatted
c      read(5,*)fmt

c     total number of atoms in a HISTORY file configuration
c      read(5,*)natms

c     time interval between successive configurations
c      read(5,*)tstep

c     max number of configurations to sample
c      read(5,*)nconf

c     working length of msd array
c      read(5,*)nmsd

c     sampling interval
c      read(5,*)isampl

c     interval between origins
c      read(5,*)iomsd

c     average cell vectors (taken from dl_poly OUTPUT file)
c      read(5,*)avcell

      nconf=min(nconf,mxconf*isampl)

c     check on specified control variables

      write(6,'(a,a40)')'# name of target HISTORY file   : ',fname
c      write(6,'(a,a8)')'# label  of atom  of interest   : ',atname
      write(6,'(a,i8)')'# total no. of atoms in config  : ',natms
      write(6,'(a,i8)')'# length of correlation arrays  : ',nmsd
      write(6,'(a,i8)')'# number of configurations      : ',nconf
      write(6,'(a,i8)')'# sampling interval             : ',isampl
      write(6,'(a,i8)')'# interval between origins      : ',iomsd
      write(6,'(a,f8.3)')'# time interval between configs : ',tstep
      write(6,'(a)')     '# average cell vectors:'
      write(6,'(a,3f12.6)')'# vector A :',avcell(1),avcell(2),avcell(3)
      write(6,'(a,3f12.6)')'# vector B :',avcell(4),avcell(5),avcell(6)
      write(6,'(a,3f12.6)')'# vector C :',avcell(7),avcell(8),avcell(9)

      if(natms.gt.mxatms)then

        write(6,'(a,2i5)')
     x    '# error - too many atoms in system'
        stop

      endif
      if(nmsd.gt.npts)then

        write(6,'(a,2i5)')
     x    '# error - msd array set too large',nmsd,npts
        stop

      endif
      if(mod(nmsd,iomsd).ne.0)then

        nmsd=iomsd*(nmsd/iomsd)
        write(6,'(a,i5)')
     x    '# warning - msd array reset to ',nmsd

      endif

      nomsd=nmsd/iomsd

c     initialise msd arrays

      lsr=0
      msr=0
      nsmsd=0
      do i=1,nstr

        acx(i)=0.d0
        acy(i)=0.d0
        acz(i)=0.d0

      enddo
      do j=1,npts
        msm(j)=0
        do i=1,nstr

          msd0(j,i,1)=0.d0
          msd0(j,i,2)=0.d0
          msd0(j,i,3)=0.d0

        enddo
        do i=1,mxconf

          msd(j,i)=0.d0

        enddo
      enddo

c     set default cell properties

      do i=1,9
        cell(i)=0.d0
      enddo
      cell(1)=11.171462
      cell(5)=11.171462
      cell(9)=11.171462

      iflg=0
      keytrj=0

      do iconf=0,nconf-1

         call hread
     x      (fname,title,atmnam,iflg,imcon,keytrj,natms,nstep,cell,
     x       chge,weight,xxx,yyy,zzz)



        if(iflg.lt.0)go to 100

c        if(imcon.ge.1.and.imcon.le.3)then

          call invert(cell,rcell,det)

c        else

c          write(6,'(a)')
c     x      '# error - incorrect boundary condition'
c          stop

c        endif

        j=0
        do i=1,nmg

c          if(atmnam(i).eq.atname)then

            j=j+1

            if(j.gt.nstr)then

              write(6,'(a)')
     x          '# error - too many atoms of specified type'
              stop

            endif
            xx1(j)=xxx(i)
            yy1(j)=xxx(i)
            zz1(j)=xxx(i)

c          endif

        enddo
        nat=j

        if(iconf.eq.0)write(6,'(a,i8)')
     x    '# no. atoms of selected type    : ',nat

        if(iconf.gt.0)then

c     accumulate incremental distances

          do i=1,nat

            uuu=xx1(i)-xx0(i)
            vvv=yy1(i)-yy0(i)
            www=zz1(i)-zz0(i)

            uuu=uuu-nint(uuu)
            vvv=vvv-nint(vvv)
            www=www-nint(www)

            acx(i)=acx(i)+uuu*cell(1)+vvv*cell(4)+www*cell(7)
            acy(i)=acy(i)+uuu*cell(2)+vvv*cell(5)+www*cell(8)
            acz(i)=acz(i)+uuu*cell(3)+vvv*cell(6)+www*cell(9)

          enddo

        endif

        do i=1,nat

          xx0(i)=xx1(i)
          yy0(i)=yy1(i)
          zz0(i)=zz1(i)

        enddo

c     calculate mean square displacement

        if(iconf.gt.0)then

          if(mod(iconf,isampl).eq.0)then

            if(mod(nsmsd,iomsd).eq.0)then

              lsr=min(lsr+1,nomsd)
              msr=mod(msr,nomsd)+1
              imd(msr)=1
              do i=1,nat

                msd0(msr,i,1)=0.d0
                msd0(msr,i,2)=0.d0
                msd0(msr,i,3)=0.d0

              enddo

            endif

            nsmsd=nsmsd+1

            do j=1,lsr

              m=imd(j)
              imd(j)=m+1
              msm(m)=msm(m)+1
              k=msm(m)
              do i=1,nat

                rmsx=msd0(j,i,1)+acx(i)
                rmsy=msd0(j,i,2)+acy(i)
                rmsz=msd0(j,i,3)+acz(i)
                msd(m,k)=msd(m,k)+rmsx**2+rmsy**2+rmsz**2
                msd0(j,i,1)=rmsx
                msd0(j,i,2)=rmsy
                msd0(j,i,3)=rmsz

              enddo

            enddo

            do i=1,nstr

              acx(i)=0.d0
              acy(i)=0.d0
              acz(i)=0.d0

            enddo

          endif

        endif

      enddo

  100 continue

      if(iflg.lt.0)iconf=iconf-1
      last=min(nsmsd,nmsd)
      write(*,*)last
      write(6,'(a,i6)')
     x  '# number of configurations read: ',iconf

c     normalise mean square displacement

      rnat=1.d0/dble(nat)
      do j=1,last

        do i=1,msm(j)

          msd(j,i)=rnat*msd(j,i)

        enddo

      enddo

c     start of blocking statistics

      do j=1,last

c     calculate average value at time t

        avg=0.d0

        do i=1,msm(j)

          avg=avg+msd(j,i)

        enddo

        avg=avg/dble(msm(j))

c     calculate estimates of sigma

        mmm=msm(j)

        nmax=0
        do n=1,ndeg

          if(mmm.gt.1)then

            sig(n)=0.d0

            do i=1,mmm

              sig(n)=sig(n)+(msd(j,i)-avg)**2

            enddo

            sig(n)=sqrt(sig(n)/(dble(mmm)*dble(mmm-1)))
            nmax=n
            mmm=mmm/2

            k=0
            do i=1,mmm

              k=k+2
              msd(j,i)=0.5d0*(msd(j,k-1)+msd(j,k))

            enddo

          endif

        enddo

c     write out results for time t

        time=tstep*dble(isampl)*dble(j)
        write(6,'(1p,12e11.4)')time,avg,(sig(i),i=1,nmax)

      enddo


      stop

      end
      subroutine invert(a,b,d)
c
c***********************************************************************
c
c     dl_poly subroutine to invert a 3 * 3 matrix using cofactors
c
c     copyright - daresbury laboratory 1992
c     author    - w. smith       april 1992
c
c***********************************************************************
c

      real*8 a,b,d,r

      dimension a(9),b(9)
c
c     calculate adjoint matrix
      b(1)=a(5)*a(9)-a(6)*a(8)
      b(2)=a(3)*a(8)-a(2)*a(9)
      b(3)=a(2)*a(6)-a(3)*a(5)
      b(4)=a(6)*a(7)-a(4)*a(9)
      b(5)=a(1)*a(9)-a(3)*a(7)
      b(6)=a(3)*a(4)-a(1)*a(6)
      b(7)=a(4)*a(8)-a(5)*a(7)
      b(8)=a(2)*a(7)-a(1)*a(8)
      b(9)=a(1)*a(5)-a(2)*a(4)
c
c     calculate determinant
      d=a(1)*b(1)+a(4)*b(2)+a(7)*b(3)
      r=0.d0
      if(abs(d).gt.0.d0)r=1.d0/d
c
c     complete inverse matrix
      b(1)=r*b(1)
      b(2)=r*b(2)
      b(3)=r*b(3)
      b(4)=r*b(4)
      b(5)=r*b(5)
      b(6)=r*b(6)
      b(7)=r*b(7)
      b(8)=r*b(8)
      b(9)=r*b(9)
      return
      end
      subroutine hread
     x  (history,cfgname,atmnam,iflg,imcon,keytrj,natms,nstep,cell,
     x   chge,weight,xxx,yyy,zzz)

c
c***********************************************************************
c
c     subroutine for reading the XYZ file
c     modified from reading HISTORY files by
c     R. Remsing, 2024
c
c     copyright - daresbury laboratory 1996
c     author    - w. smith jan 1996.
c
c     single processor version
c
c     wl
c     1997/02/20 14:47:11
c     1.1
c     Exp
c
c***********************************************************************
c

      implicit real*8(a-h,o-z)

      logical new

      character*80 cfgname
      character*40 history
      character*8 atmnam(*),step
      character*80 dummy

      dimension cell(9)
      dimension chge(*),weight(*)
      dimension xxx(*),yyy(*),zzz(*)

      save new

      data new/.true./,nhist/77/

      iflg=0

c     open history file if new job


      open(nhist,file=history,status='old', err=100)

      read(nhist,*,err=200) matms

      read(nhist,*) dummy
!      read(nhist,*)cell(1),cell(2),cell(3)
!      read(nhist,*)cell(4),cell(5),cell(6)
!      read(nhist,*)cell(7),cell(8),cell(9)
!      read(nhist,*)dummy
!      read(nhist,*)matms
!      read(nhist,*)dummy

      if(natms.ne.matms)then

        write(*,'(a)')'# error - incorrect number of atoms in file'
        write(*,'(i6)')'# file contains',matms,' atoms'
        stop

      endif


      do i = 1,natms
        read(nhist,*)dummy,xxx(i),yyy(i),zzz(i)
      enddo

      iflg=1

      return

  100 continue

      write(*,'(a)')'# error - History file not found'
      stop

  200 continue
      write(*,'(a)')'# warning - end of History file encountered'
      close (nhist)
      iflg=-1

      return
      end


