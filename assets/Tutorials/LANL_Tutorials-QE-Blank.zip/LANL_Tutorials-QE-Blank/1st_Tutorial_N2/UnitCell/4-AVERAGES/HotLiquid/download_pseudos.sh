#!/bin/bash
BASE_URL="https://pseudopotentials.quantum-espresso.org/upf_files"
for upf in N.pbe-n-kjpaw_psl.1.0.0.UPF ; do
    if [ ! -f $upf ] ; then wget -q "${BASE_URL}/${upf}" || curl -sO "${BASE_URL}/${upf}" ; fi
done
