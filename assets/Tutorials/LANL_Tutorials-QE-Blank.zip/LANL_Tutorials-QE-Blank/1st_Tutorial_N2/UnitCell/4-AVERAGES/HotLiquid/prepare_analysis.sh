#!/bin/bash
# Run after simulation completes: creates N2-MD-pos-1.xyz and N2-MD-1.ener
# These files are read by RunRDF.sh, RunMSD.sh, ComputeTemperatureFlucs.py, etc.
DT_FS=1.0
python ../AnalysisCode/extract_traj.py N2-MD.out N2-MD-pos-1.xyz $DT_FS
python ../AnalysisCode/make_ener_file.py N2-MD.out N2-MD-1.ener $DT_FS
echo "Ready: N2-MD-pos-1.xyz and N2-MD-1.ener"
