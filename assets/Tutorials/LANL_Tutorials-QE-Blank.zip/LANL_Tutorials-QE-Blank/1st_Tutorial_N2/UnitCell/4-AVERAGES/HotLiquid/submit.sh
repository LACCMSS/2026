#!/bin/bash
#SBATCH --job-name=N2-hot
#SBATCH --nodes=1
#SBATCH --ntasks=16
#SBATCH --cpus-per-task=1
#SBATCH --mem=32G
#SBATCH --time=00-04:00:00
#SBATCH --output=slurm.%N.%j.o
#SBATCH --error=slurm.%N.%j.err

module load quantumespresso
QE_BIN=pw.x

mpirun -np $SLURM_NTASKS $QE_BIN -in N2.in > N2-MD.out
