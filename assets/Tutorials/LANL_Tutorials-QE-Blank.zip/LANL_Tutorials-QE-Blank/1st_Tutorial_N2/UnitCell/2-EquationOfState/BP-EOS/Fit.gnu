# Murnaghan EOS for BP-nitrogen
# Volume = scale^3 * ax*ay*az = scale^3 * 42.121 Ang^3
f(x)=E0+K*V*( (1.0/(K2*(K2-1)))*(x/V)**(1.0-K2) + 1.0/K2*x/V - 1.0/(K2-1.0) )

K=1.0
K2=4.0
E0=-224.6
V=105.3

# k-point converged (6x2x4 mesh + cold smearing): the EOS is smooth, fit full range.
fit f(x) 'Energy.dat' u ($1**3*42.121):2 via K,K2,E0,V

print K,K2,E0,V

set key outside
set pointsize 3
set ylabel 'Energy (Ry)'
set xlabel 'Volume (Ang^3)'
p 'Energy.dat' u ($1**3*42.121):2 w p pt 6, f(x) lw 3
