#!/usr/bin/perl -W

open(INS,"Scales.txt");
while(<INS>)
{
	@tmp=split(/\s+/,$_);
	push(@s,$tmp[0]);
}
close(INS);

open(IN,"Energy_volume.dat");
while(<IN>)
{
	@tmp=split(/\s+/,$_);
	push(@E,$tmp[0]);
}
close(IN);

open(OUT,">Energy.dat");
for($i=0;$i<@E;$i++)
{
	print OUT "    $s[$i]    $E[$i]\n";
}
close(OUT);
