#!/bin/bash
rm -f Energy_volume.dat Scales.txt
for ii in INSERT_SCALES_HERE
do
    grep '!    total energy' scale_${ii}/N2.out | tail -n 1 | awk '{print $5}' >> Energy_volume.dat
    echo $ii >> Scales.txt
done
perl PrintEnergyFile.pl
