#!/bin/bash
scales=" "

pseudo_file=N.pbe-n-kjpaw_psl.1.0.0.UPF
template_file=N2-template.in
input_file=N2.in
ax=2.1612
ay=6.8312
az=2.8530

for sc in $scales ; do
    Lx=$(awk "BEGIN {printf \"%.6f\", ${sc} * ${ax}}")
    Ly=$(awk "BEGIN {printf \"%.6f\", ${sc} * ${ay}}")
    Lz=$(awk "BEGIN {printf \"%.6f\", ${sc} * ${az}}")
    work_dir=scale_${sc}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -rf $work_dir/*
    fi
    sed -e "s/LT_Lx/${Lx}/g" \
        -e "s/LT_Ly/${Ly}/g" \
        -e "s/LT_Lz/${Lz}/g" \
        $template_file > $work_dir/$input_file
    cp $pseudo_file $work_dir/ 2>/dev/null || echo "Note: run download_pseudos.sh first"
done
