# Murnaghan Equation of State
# Energy in Ry, volume in Ang^3
f(x)=E0+K*V*( (1.0/(K2*(K2-1)))*(x/V)**(1.0-K2) + 1.0/K2*x/V - 1.0/(K2-1.0) )

# Initial guesses (E0 in Ry for 8-atom alpha-N2 cell with PAW-PBE)
K=1.0
K2=5.0
E0=-154.0
V=200.0

fit f(x) 'Energy.dat' u (($1*5.856)**3):2 via K,K2,E0,V

print K,K2,E0,V

set key outside
set pointsize 3
set ylabel 'Energy (Ry)'
set xlabel 'Volume (Ang^3)'
p 'Energy.dat' u (($1*5.856)**3):2 w p pt 6, f(x) lw 3
