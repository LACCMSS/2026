#!/bin/bash
scales=" "

pseudo_file=N.pbe-n-kjpaw_psl.1.0.0.UPF
template_file=N2-template.in
input_file=N2.in
a0=5.856000

for sc in $scales ; do
    L=$(awk "BEGIN {printf \"%.6f\", ${sc} * ${a0}}")
    work_dir=scale_${sc}
    if [ ! -d $work_dir ] ; then
        mkdir $work_dir
    else
        rm -rf $work_dir/*
    fi
    sed -e "s/LT_L/${L}/g" \
        $template_file > $work_dir/$input_file
    cp $pseudo_file $work_dir/ 2>/dev/null || echo "Note: run download_pseudos.sh first"
done
