#!/bin/bash
output_file=AgI-MD.out
energy_file=energies.dat

echo "# Step  Total_Energy_Ry  Total_Energy_eV" > $energy_file
grep "!    total energy" $output_file | \
    awk 'BEGIN {ry_to_ev=13.6057} \
         {e=$(NF-1); printf "%d  %14.8f  %14.8f\n", NR, e, e*ry_to_ev}' \
    >> $energy_file

nsteps=$(grep -c "!    total energy" $output_file)
echo "Extracted $nsteps energy values to $energy_file"
