#!/bin/bash
#SBATCH --job-name=AgI-AIMD
#SBATCH --nodes=2
#SBATCH --ntasks=64
#SBATCH --cpus-per-task=1
#SBATCH --mem=128G
#SBATCH --time=01-00:00:00
#SBATCH --output=slurm.%N.%j.o
#SBATCH --error=slurm.%N.%j.err

module load quantumespresso
QE_BIN=pw.x

mpirun -np $SLURM_NTASKS $QE_BIN -in agi-aimd.in > AgI-MD.out
