#!/usr/bin/env python3
"""
Convert QE pw.x MD output to extended XYZ for NequIP/MACE training.
Usage: python qe-2-extxyz.py <qe_output_file> <extxyz_output_file>

Extended XYZ format:
  nat
  Lattice="..." Properties=species:S:1:pos:R:3:forces:R:3 energy=VALUE pbc="T T T"
  Ag  x  y  z  fx  fy  fz
  ...

Units: positions in Angstrom, forces in eV/Ang, energy in eV.
QE outputs: positions in Ang, forces in Ry/Bohr, energy in Ry.
Conversions: 1 Ry = 13.6057 eV; 1 Ry/Bohr = 13.6057/0.529177 eV/Ang = 25.7110 eV/Ang
"""
import sys
import re
import numpy as np

RY_TO_EV = 13.6057
RY_BOHR_TO_EV_ANG = 13.6057 / 0.529177  # 25.7110 eV/Ang

def parse_qe_output(qe_out):
    with open(qe_out) as f:
        content = f.read()

    # Cell from first CELL_PARAMETERS block (assumed fixed for NVT)
    cell_m = re.search(
        r'CELL_PARAMETERS\s*\{angstrom\}\s*\n'
        r'\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*\n'
        r'\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)\s*\n'
        r'\s*([-\d.]+)\s+([-\d.]+)\s+([-\d.]+)',
        content)
    if cell_m:
        cell = np.array([float(x) for x in cell_m.groups()]).reshape(3, 3)
    else:
        # Fallback: try alat from output header
        alat_m = re.search(r'lattice parameter \(alat\)\s*=\s*([\d.]+)\s*a\.u\.', content)
        a = float(alat_m.group(1)) * 0.529177 if alat_m else 10.171
        cell = np.diag([a, a, a])

    # Parse all ATOMIC_POSITIONS blocks
    pos_pat = re.compile(
        r'ATOMIC_POSITIONS\s*\([^)]*\)\n'
        r'((?:[ \t]*\S+[ \t]+[-\d.]+[ \t]+[-\d.]+[ \t]+[-\d.]+\n)+)'
    )
    # Parse all force blocks
    force_pat = re.compile(
        r'Forces acting on atoms.*?\n'
        r'((?:.*?atom\s+\d+.*?force\s*=\s*[-\d.]+\s+[-\d.]+\s+[-\d.]+\n)+)',
        re.DOTALL
    )
    # Parse all total energies
    energies = [float(x) * RY_TO_EV
                for x in re.findall(r'!\s+total energy\s+=\s+([-\d.]+)\s*Ry', content)]

    pos_blocks = pos_pat.findall(content)
    force_blocks = force_pat.findall(content)

    n = min(len(pos_blocks), len(energies))
    frames = []
    for i in range(n):
        atoms = pos_blocks[i].strip().split('\n')
        elements = [a.split()[0] for a in atoms]
        positions = [[float(v) for v in a.split()[1:4]] for a in atoms]

        forces = []
        if i < len(force_blocks):
            for line in force_blocks[i].strip().split('\n'):
                if 'force' in line:
                    parts = line.split()
                    idx = parts.index('=') + 1
                    forces.append([float(parts[idx]) * RY_BOHR_TO_EV_ANG,
                                   float(parts[idx+1]) * RY_BOHR_TO_EV_ANG,
                                   float(parts[idx+2]) * RY_BOHR_TO_EV_ANG])
        if not forces:
            forces = [[0.0, 0.0, 0.0]] * len(elements)

        frames.append({'elements': elements, 'positions': positions,
                       'forces': forces, 'energy': energies[i], 'cell': cell})
    return frames

def write_extxyz(frames, outfile):
    with open(outfile, 'w') as f:
        for fr in frames:
            nat = len(fr['elements'])
            c = fr['cell']
            lat = ' '.join(f'{x:.6f}' for row in c for x in row)
            f.write(f'{nat}\n')
            f.write(f'Lattice="{lat}" Properties=species:S:1:pos:R:3:forces:R:3 '
                    f'energy={fr["energy"]:.8f} pbc="T T T"\n')
            for j, el in enumerate(fr['elements']):
                p = fr['positions'][j]
                fv = fr['forces'][j]
                f.write(f'{el}  {p[0]:.8f}  {p[1]:.8f}  {p[2]:.8f}'
                        f'  {fv[0]:.8f}  {fv[1]:.8f}  {fv[2]:.8f}\n')
    print(f"Wrote {len(frames)} frames to {outfile}")

if __name__ == '__main__':
    if len(sys.argv) != 3:
        print("Usage: python qe-2-extxyz.py <qe_output_file> <extxyz_output_file>")
        sys.exit(1)
    frames = parse_qe_output(sys.argv[1])
    write_extxyz(frames, sys.argv[2])
    print(f"Parsed {len(frames)} frames total")
